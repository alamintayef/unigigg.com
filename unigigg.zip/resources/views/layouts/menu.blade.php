<div class="col-md-2">
  <ul class="list-group">
    <li class="list-group-item">
      <a href="{{url('home')}}"><strong><i class="fa fa-dashboard"></i> Dashboard</strong></a>

    </li>
    <li class="list-group-item">
      <a href="{{url('userinfo')}}"><strong><i class="zmdi zmdi-settings"></i> Build Profile</strong></a>

    </li>
    <li class="list-group-item">
      <a href="{{url('chakri')}}"><strong><i class="small material-icons">work</i> Jobs</strong></a>

    </li>


  </li>
  <li class="list-group-item">
    <a href="{{url('jobsapplied')}}"><strong>Jobs Applied</strong></a>

  </li>
  <li class="list-group-item">
    <a href="http://blog.unigigg.com"><strong>Resources</strong></a>

  </li>
  <li class="list-group-item">
    <a href="#"><strong>Jobs Sorted</strong></a>
  </li>
  <li class="list-group-item dropdown">
      <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
      <strong> <i class="fa fa-btn fa-tasks"></i>  Eccentric-Jobs <span class="caret"></span></strong>
      </a>
      <ul class="dropdown-menu" role="menu">
      <li class="list-group-item">
        <a href="{{url('eccentricJobspost')}}"><strong>Post an Eccentric Job</strong></a>

      </li>
      <li class="list-group-item">
        <a href="{{url('eccentricJobs')}}"><strong>Eccentric Job</strong></a>

      </li>
      <li class="list-group-item">
        <a href="{{url('eccentricJobsiApplied')}}"><strong>Applied Jobs</strong></a>

      </li>
      <!--
      <li class="list-group-item">
        <a href="{{url('eccentricJobsApplied')}}"><strong><i class="fa fa-edit"></i>Jobs Posted By You</strong></a>

      </li>
    -->
      <li class="list-group-item">
        <a href="{{url('eccentricJobsApplied')}}"><strong>Applied for Your Job</strong></a>

      </li>
    </ul>



  </li>



  </ul>
</div>
