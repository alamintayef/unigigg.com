<h1>Hello {{$calls->fname}} </h1>
<p>
    you been called on an interview for {{$calls->title}} in {{$calls->name}}.<br>
    You may please call and confirm the appointment

</p>
