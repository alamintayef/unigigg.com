<h1>Hello {{$calls->fname}} </h1>
<p>
    you been called on an interview for {{$calls->job_name}} in {{$calls->company_name}}.<br>
    You may please call and confirm the appointment {{$calls->company_phone}}

</p>
