<h1>Hello {{$calls->fname}} {{$calls->fname}} </h1>
<p>
    you been called on an interview for the postion: {{$calls->job_name}} by {{$calls->company_name}}.<br>
    You may please call and confirm the appointment {{$calls->company_phone}}<br>

    We wish you best of luck <br>
    Regards,<br>
    <em>unigigg team</em>

</p>
