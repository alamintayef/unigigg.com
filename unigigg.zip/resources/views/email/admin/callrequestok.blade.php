<h2>Dear {{$employer->company_name}}</h2>
<p>
  Your request to call the candidates for the postion : <strong>{{$employer->job_name}}</strong> has been successfully processed.<br>
  You can now go to shortlisted candidates and see candidates full profile with all the details
</p>
<p>
  Thank you for using unigigg. <br>
  We wish you best of luck, <br>
  Regards, <br>
  <em>unigigg team</em>
</p>
