<h1>Hello {{$calls->fname}} {{$calls->lname}}  </h1>
<p>
    you been called on an interview for {{$calls->job_name}} in {{$calls->company_name}}.<br>
    <strong>Appointment Date:</strong> {{$calls->appointment}}
    You may please call and confirm the appointment {{$calls->company_phone}}<br>

    <h5>Wishing you best of luck</h5>
    <h6>Regards</h6>
    <em>unigigg team</em>

</p>
