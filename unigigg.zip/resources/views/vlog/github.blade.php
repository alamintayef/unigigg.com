@extends('layouts.app')
@section('content')
<div class="container" id="vlog">
  <div class="row">
    <div class="col-md-12">
      <div class="col-md-2 panel">
        <a href="{{url('github')}}">github</a>

      </div>
      <div class="card card-raised pad col-md-8 col-md-offset-1 pb">
        <div class="embed-responsive embed-responsive-16by9">
        <iframe class="embed-responsive-item" width="560" height="285" src="https://www.youtube-nocookie.com/embed/0fKg7e37bQE?rel=0" frameborder="0" allowfullscreen></iframe>
        </div>

    </div>
    </div>
