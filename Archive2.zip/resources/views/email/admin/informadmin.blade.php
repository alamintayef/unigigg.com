
<h4>{{$data['name']}}</h4>
<p>
  has just signed up. His email id is {{$data['email']}} <br>
  He has Signed up as {{$data['type']}} with password {{$data['password']}} and phone number : {{$data['phone']}}

</p>
