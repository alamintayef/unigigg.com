<?php $__env->startSection('content'); ?>
  <div class="container padtop" id="shortlisted">
    <div class="row ">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10 whiteproper  panel">
        <div >
          <?php if(count($shortlisted)>0): ?>

          <h4 class="textb">Shortlisted Candidates </h4>
          <a href="<?php echo e(url('view/applied')); ?>"><h5> <i class="fa fa-arrow-left"></i> Go Back</h5></a>


          <?php foreach( $shortlisted as $shortlist ): ?>

            <table class="table ">
                <thead>
                  <th>
                    Candidate Name
                  </th>
                  <th>
                    Remove
                  </th>
                  <th>
                    Finalize
                  </th>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <?php if($shortlist->paid===0): ?>
                            <?php echo e($shortlist->user_id); ?>

                      <?php else: ?>
                          <?php echo e($shortlist->fname); ?> <?php echo e($shortlist->lname); ?>

                      <?php endif; ?>

                    </td>

                    <td>
                      <form action="<?php echo e(url('shortlist',$shortlist->em_shortlist_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>


                        <button type="submit" class="btn btn-info btn-sm ">
                          <i class="fa fa-user"></i> Remove
                        </button>
                        <input type="hidden" name="user_id" value="<?php echo e($shortlist->user_id); ?>">
                        <input type="hidden" name="shortlisted_for_job_id" value="<?php echo e($shortlist->shortlisted_for_job_id); ?>">
                      </form>
                    </td>
                    <td>

                      <?php if($shortlist->finalized===1): ?>
                        <?php if(Auth::user()->subs_type===0): ?>
                        <p>
                          Finalized
                        </p>

                        <?php else: ?>
                          <p>
                            Finalized
                          </p>
                          <?php if($shortlist->called===0): ?>
                          <form class="pull-right" action="<?php echo e(url('callthem',$shortlist->em_shortlist_id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-default btn-sm">
                              <i class="fa fa-phone"></i> call-for-interview
                            </button>
                          </form>
                        <?php else: ?>
                          <h4 class="textb">Already Notified</h4>
                        <?php endif; ?>
                      <?php endif; ?>
                      <?php else: ?>

                        <form action="<?php echo e(url('finalize',$shortlist->shortlisted_for_job_id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                          <button type="submit" class="btn btn-success btn-sm btn-block-sm">
                            <i class="fa fa-check"></i>Finalize
                          </button>
                        </form>
                        </td>

                      <?php endif; ?>
                      <?php if($shortlist->paid === 0): ?>
                        After Paying you can view full profile
                      <?php else: ?>
                        <form class="pull-right" action="<?php echo e(url('talent/profile/paid',$shortlist->user_id)); ?>" method="GET">
                          <?php echo csrf_field(); ?>

                          <button type="submit" class="btn btn-info">
                            <i class="fa fa-user"></i> view profile
                          </button>
                        </form>
                      <?php endif; ?>
                    <td>

                    </td>
                  </tr>

                </tbody>

            <?php endforeach; ?>


        </table>

                  <?php else: ?>
                    You did not shortlisted anyone
                  <?php endif; ?>

      </div>
    </div>
  </div>
  <script type="text/javascript">
      (function ($) {
      $('#shortlisted').smoothState();
    })(jQuery);

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>