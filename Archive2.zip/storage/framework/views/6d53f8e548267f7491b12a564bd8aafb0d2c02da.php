<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">
      <div class="card card-raised">

      <table class="table">
        <thead>
          <th>
          Verification Request From
          </th>
          <th>
            Number
          </th>
          <th>
          Transaction ID
          </th>
          <th>
            Profile
          </th>
          <th>
            verify
          </th>
          <th>
            Undo
          </th>
        </thead>
        <?php foreach($varreqs as $verify): ?>
          <tbody>
          <tr>
            <td>
              <?php echo e($verify->name); ?>

            </td>
            <td>
              <?php echo e($verify->bkash_number); ?>

            </td>
            <td>
              <?php echo e($verify->transaction_id); ?>

            </td>
            <td>
              <form  action="<?php echo e(url('/aprofile',$verify->id)); ?>" method="GET">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-primary">
                  <i class="fa fa-user"></i> View profile
                </button>
              </form>
            </td>
            <?php if($verify->verified===1): ?>
              <td>
                <button type="button" class="btn-success">
                  Already Verified
                </button>
              </td>

              <td>
                <form class="form-group" action="<?php echo e(url('/undo/verify',$verify->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-sm raised btn-warning">
                    <i class="fa fa-check"></i> undo
                  </button>
                </form>
              </td>
            <?php else: ?>
              <td>
                <form class="form-group" action="<?php echo e(url('/verify',$verify->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Verify
                  </button>
                </form>
              </td>

            </tr>
          </tbody>
            <?php endif; ?>

          <?php endforeach; ?>
            <?php echo e($varreqs->links()); ?>

      </table>
    </div>
    </div>

  </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>