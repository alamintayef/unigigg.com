<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <p>

    Dear Applicant,<br>

    Thanks for applying through unigigg.com and your interest in the position of <b> <?php echo e($user->job_name); ?></b> <br>

    We appreciate the opportunity to consider you for a position and the employer reviewed your skills and experience and have decided to proceed with other candidates who met employer needs more accurately for the post.<br>
    This was an extremely competitive process, and we received hundreds of applications. This was definitely a tough decision for us, as you were a solid candidate.<br><br>

    So build up your skills more precious and Wish you the best of luck in your job search and thank you again for choosing unigigg.com to apply.<br>


    Best,
    Unigigg Team

  </p>

  </body>
</html>
