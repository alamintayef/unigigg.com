<div class="padsmall col-md-12" >
  <h4>Experience</h4>

  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>
          Title
        </th>

        <th>
          Starting Date
        </th>
        <th>
          End Date
        </th>
        <th>
          Description
        </th>

        <tr>
        </thead>
        <tbody>
          <?php foreach($experiences as $experience): ?>
            <tr>
              <td>
                <?php echo e($experience->exp_name); ?>

              </td>

              <td>
                <?php echo e($experience->exp_start_date); ?>

              </td>
              <td>
                <?php echo e($experience->exp_end_date); ?>

              </td>
              <td>
                <?php echo e($experience->exp_description); ?>

              </td>
              <td>
                <form action="<?php echo e(url('experience',$experience->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger ">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
              </td>
            <?php endforeach; ?>

          </tbody>
        </table>


      </div>
