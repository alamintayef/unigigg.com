<?php $__env->startSection('content'); ?>
<style media="screen">
.pl
{
  padding: 10px;
}
.ft
{
  font-size: 13px;
}
.td {
  width:150px;
}
</style>
<div class="container padtop">
  <div class="row">
    <?php if(Auth::user()->type==2): ?>
      <a href="<?php echo e(url('whoapplied')); ?>">Go Back</a>
    <?php elseif(Auth::user()->type==1): ?>
      <a href="<?php echo e(url('home')); ?>">Go Back</a>
    <?php else: ?>
      <a href="<?php echo e(url('admin')); ?>">Go Back</a>
    <?php endif; ?>

    <div class="col-md-10 col-sm-10 col-xs-10">

      <div class="panel panel-blue" >
        <div class="panel-heading">
          <div class="pull-right pl">
            <?php foreach($images as $image): ?>
              <img src="<?php echo ' /files/images/'.$image->filePath; ?>" alt="propic" height="100px" width="100px" style="border-radius:50%;" />
            <?php endforeach; ?>
            <br>
            <br>

            <?php if(count($about)>0): ?>
            <?php foreach($about as $info): ?>


                <div class="well">

                  <?php echo $info->fun_facts; ?><br>
                  <?php echo $info->inspiration_qot; ?><br>
                  <?php echo e($info->Why_you); ?><br>
                  <?php echo e($info->Why_not_you); ?><br>
                </div>
                  <?php endforeach; ?>
              <?php else: ?>
                <p>
                  About not added
                  <form class="form-group" action="<?php echo e(url('/notify/user/about',$user->email)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-sm raised btn-primary">
                      <i class="fa fa-check"></i> Notify for about
                    </button>
                  </form>
                </p>


            <?php endif; ?>
            <?php if($user->verified===1): ?>
              <p class="text-success">
                Verified
              </p>
            <?php else: ?>
              <p class="text-danger">
                Not Verified
              </p>
            <?php endif; ?>
            <?php if($user->subs_type===0): ?>
              <p class="text-warning">
                Free
                <form class="form-group" action="<?php echo e(url('/verify',$user->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-success">
                    <i class="fa fa-check"></i> Change
                  </button>
                </form>
              </p>
            <?php else: ?>
              <p class="text-success">
                Subscribed
              </p>
            <?php endif; ?>

          </div>
          <?php if(count($view)>0): ?>

            <h3 class="textb"><?php echo e($view->fname); ?>   <?php echo e($view->lname); ?></h3>

          </div>
          <div class="panel-body ft pl">
            <div >

              <p>
                University :<?php echo e($view->institute); ?><br>
                Phone Number : <?php echo e($view->mobile); ?>

                NID :<?php echo e($view->NId); ?><br>
                Facebook : <a href="<?php echo e($view->facebookId); ?>"> Facebook</a> <br>
                LINKEDIN : <a href="<?php echo e($view->LinkedInId); ?>"> Linkedin</a>
              </p>

            </div>

          <?php else: ?>
            Nothing added
            <form class="form-group" action="<?php echo e(url('/notify/user/info',$user->email)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-sm raised btn-primary">
                <i class="fa fa-check"></i> Notify for info
              </button>
            </form>

          <?php endif; ?>
          <?php if(count($interest)>0): ?>
              <h4><a href="<?php echo e($interest->interest_name); ?>">CV</a></h4>

          <?php endif; ?>

          <?php if(count($skill)>0): ?>

            <h4>Skills</h4>
            <table class="table ft table-responsive">
              <thead>
                <th>
                  Title
                </th>
                <th>
                  Level
                </th>
                <th>
                  Proof
                </th>
                <th>
                  Verification
                </th>
              </thead>
              <?php foreach($skill as $skills): ?>

                <tbody>
                  <tr>
                    <td class="td">
                      <?php echo e($skills->skill_name); ?>

                    </td>
                    <td class="td">
                      <?php echo e($skills->skill_level); ?>

                    </td>
                    <td>
                      <a href="<?php echo e($skills->skill_proof); ?>"> <?php echo e($skills->skill_name); ?></a>
                    </td>
                    <td>
                        <?php if($skills->varified===0): ?>
                          <button type="button" name="button" class="btn-danger">Not Verified</button>
                        <?php else: ?>
                          <button type="button" name="button" class="btn-success">Verified</button>
                        <?php endif; ?>
                      </td>
                    </tr>
                </tbody>
              <?php endforeach; ?>
            </table>
          <?php else: ?>
            Nothing added
            <form class="form-group" action="<?php echo e(url('/notify/user/skill',$user->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-sm raised btn-primary">
                <i class="fa fa-check"></i> Notify for skills
              </button>
            </form>
          </td>
        <?php endif; ?>

        <?php if(count($education)>0): ?>
          <h4>Education</h4>
          <?php foreach($education as $edu ): ?>
            <div class="panel panel-default">
              <div class='panel-heading'>
                <h4 class="panel-title"> <strong>Degree:</strong>  <?php echo e($edu->Degree_name); ?></h4>
                <strong>Type:</strong>  <?php echo e($edu->Degree_type); ?>

              </div>
              <div class="panel-body">
                <strong>Institute</strong><span class="pl"> <?php echo e($edu->Degree_institute); ?></span>
                <strong>Results</strong> <span class="pl"> <?php echo e($edu->Degree_result); ?></span>
                <strong> Start Date: </strong><span class="pl"> <?php echo e($edu->Degree_start_date); ?></span>
                <strong> Passing Date: </strong><span class="pl"><?php echo e($edu->Degree_end_date); ?></span>
              </div>
        <?php endforeach; ?>

          <?php else: ?>
            No education info added yet
            <form class="form-group" action="<?php echo e(url('notify/user/education',$user->email)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-sm raised btn-primary">
                <i class="fa fa-check"></i> Notify for education
              </button>
            </form>

          <?php endif; ?>

        </div>
        <hr>
        <?php if(count($exps)>0): ?>

        <h4 class="pl">Experiences</h4>
          <div class="pl">
            <?php foreach($exps as $exp ): ?>
              <hr>
              <p class="pl">
                <strong>Title:</strong> <?php echo e($exp->exp_name); ?><br>
                <strong>Description</strong>:<br>
                <?php echo e($exp->exp_description); ?><br>
                <small><strong>start date :</strong></small> <?php echo e($exp->exp_start_date); ?> <small><strong>end date :</strong></small> <?php echo e($exp->exp_end_date); ?>

              </p>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          No experience info added yet
          <form class="form-group" action="<?php echo e(url('notify/user/experience',$user->email)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <button type="submit" class="btn btn-sm raised btn-primary">
              <i class="fa fa-check"></i> Notify for Experience
            </button>
          </form>
        <?php endif; ?>
        <?php if(count($refs)>0): ?>


          <h4 class="pl">References</h4>
          <div class="pl" >
            <?php foreach($refs as $ref ): ?>
              <p>
                <strong>Referred By</strong> <?php echo e($ref->referred_by); ?><br>
                <strong>Description</strong>:<br>
                <?php echo e($ref->reference_description); ?><br>
                <small><strong>Contact : </strong><?php echo e($ref->referee_number); ?></small>  </p>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <?php if(count($vdo)>0): ?>


            <div class="center card card-raised padsmall embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" width="460" height="275" src="https://www.youtube.com/embed/<?php echo e($vdo->vdourl); ?>" frameborder="0" allowfullscreen></iframe>

            </div>
          <?php endif; ?>



        </div>
        <!--

        <div class="panel-footer">
        <button type="button" name="button">Shortlist</button>
      </div>
    </div>
  -->

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>