<title><?php echo e($article->title); ?></title>
<?php $__env->startSection('content'); ?>
  <style media="screen">
    p{
      font-size: 20px;
    }

  </style>

<div class="container center padtop" id="font">
  <div class="row">
    <div class="col-lg-12 padsmall">

      <div class="panel col-md-10 col-md-offset-1">


        <h3><?php echo e($article->title); ?></h3>
        <p>
          <?php echo $article->body; ?>

        </p>
        <hr>
        Share it on :
        <a href="https://www.facebook.com/sharer/sharer.php?u=www.unigigg.div/blog/article/<?php echo e($article->slug); ?>" target="_blank">
         <i class="fa fa-facebook fa-2x"></i>
      </a>
      </div>


    </div>

  </div>

</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>