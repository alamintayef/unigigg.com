<?php $__env->startSection('content'); ?>
  <script type="text/javascript">
  (function ($) {
    $('#vprofile').smoothState();
 }) (jQuery);

  </script>
  <div class="container padtop" id="vprofile">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-7">

        <ul class="nav nav-pills panel whiteproper">
          <li ><a href="<?php echo e(url('userinfo')); ?>">Basic Information</a></li>
          <li ><a href="<?php echo e(url('image')); ?>">Profile Pic</a></li>
          <li ><a href="<?php echo e(url('edu')); ?>">Education</a></li>
          <li  ><a href="<?php echo e(url('skill')); ?>">Skills</a></li>
          <li ><a href="<?php echo e(url('experience')); ?>">Experience</a></li>
          <li ><a href="<?php echo e(url('refs')); ?>">Reference</a></li>
          <li ><a href="<?php echo e(url('excc')); ?>">Extra-Curricular</a></li>
          <li><a href="<?php echo e(url('interest')); ?>">Upload CV</a></li>
            <li ><a href="<?php echo e(url('hobby')); ?>">Cover Letter</a></li>
          <li><a href="<?php echo e(url('fun')); ?>">About You</a></li>
          <li class="active"><a href="<?php echo e(url('vdoprofile')); ?>">Video Resume</a></li>
        </ul>


            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            <?php if(notify()->ready()): ?>
              <script>
              swal({
                title: "<?php echo notify()->message(); ?>",
                text: "<?php echo notify()->option('text'); ?>",
                type: "<?php echo e(notify()->type()); ?>",
                <?php if(notify()->option('timer')): ?>
                timer: <?php echo e(notify()->option('timer')); ?>,
                showConfirmButton: false
                <?php endif; ?>
              });
              </script>
            <?php endif; ?>


            <?php echo $__env->make('student.forms.vprofile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-md-3 panel card-raised whiteproper padsmall pull-right">

                <h4 class="textb">Instructions</h4>
                <p>
                  Upload a video introduction yours on youtube and paste in link here.
                </p>
                <p>
                  Example: <br>
                  <small><span class="text-success">https://www.youtube.com/watch?v=rz66fpmIZCQ</span></small>

                </p>
                <p>
                  Upload a video of yours on youtube containing your introduction
                  in 30 seconds. A simple video reveals a lot about you then a CV, thats why we ask for video intro.
                </p>
                <p>
                  Exclude your contact details. Focus only on your self on the video
                </p>

              </div>


    </div>

  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>