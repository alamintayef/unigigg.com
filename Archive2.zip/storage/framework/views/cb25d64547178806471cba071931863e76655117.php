<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.2.61/jspdf.min.js"></script>


</script>
<title>Resume</title>
<style>
#header {
  background-color:black;
  color:white;
  text-ah5gn:center;

}

#nav {
  h5ne-height:20px;
  background-color:#eeeeee;
  height:300px;
  width:100px;
  float:left;
  padding:5px;
}
.right{
  text-align: right;
}
.left{
  text-align: left;
}
html{
    background: #ededed;
}
body{
  padding: 3px;

}
.supersmall{
  text-align: right;
  font-size: 8px;
}
.small{
  text-align: right;
  font-size: 18px;
}
#section {
  width:350px;
  float:left;
  padding:10px;
}
.smallpad{
  padding: 3px;
}
#footer {
  background-color:black;
  color:white;
  clear:both;
  text-ah5gn:center;
  padding:5px;
}
td {
  width:180px;
  font:12pt arial;}

  td.leftAlign {text-align:left;}
  td.rightAlign {text-align:right;}
  td.center {text-align:center;}
  td.justify {text-align:justify;}

ul.skills {
  	margin:0;
  	padding:0;
  	float:right;
  	width:500px;
  	margin-left:40px;
  	margin-top:-6px;
  	list-style-type: none;

  }

ul.skills li {
  	margin:0;
  	padding:0;
  	float:left;
  	width:156px;

  	background-repeat: no-repeat;
  	padding-left:10px;
  	background-position: 0 .5em;
  	margin-top:6px;
  }
  div.content {
  	clear: both;
  	padding:0;
  	margin:0;
  	overflow: hidden;
  	display:block;
  	padding-top:32px;
  }
  section {
  	border-top: 1px solid #dedede;
  	padding: 10px 0 0;
  }

  section:first-child {
  	border-top: 0;
  }
  .clear {clear: both;}

  section:last-child {
  	padding: 20px 0 10px;
  }

  .sectionTitle {
  	float: left;
  	width: 25%;
  }

  .sectionContent {
  	float: right;
  	width: 72.5%;
  }

  .sectionTitle h1 {
  	font-family: 'Rokkitt', Helvetica, Arial, sans-serif;

  	font-size: 1.2em;
  	color: #cf8a05;
  }

.sectionContent h2 {
  	font-family: 'Rokkitt', Helvetica, Arial, sans-serif;
  	font-size: 1.5em;
  	margin-bottom: -2px;
  }
.menu ul { padding:0; margin:0; list-style:none; border:0;}
.menu ul li {
   margin-right:10px;
   padding-right:10px;
   padding-bottom: 20px;
   border:0;
   display: inline;
   float: left;
 }

</style>


</head>
<body onload="window.print()" >

  <main class="pad">
    <div id="details">

      <div id="invoice">
        <div class="left">
        
        </div>
        <div class="right">
          <?php foreach($data as $user): ?>
          <h2><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h2>
          <small class="small">  <?php echo e($user->mobile); ?><br>
            <?php echo e($user->area); ?><br>
          <?php endforeach; ?>
          <?php echo e(Auth::user()->email); ?></small>
          <hr>
          </div>
        </div>
      </div>
    </main>
    <section>
      <div class="sectionTitle">
        <h1>Key Skills</h1>
      </div>
      <?php if(count($skill)>0): ?>

      <div class='menu'>
        <ul >
          <?php foreach($skill as $skills): ?>
            <li><?php echo e($skills->skill_name); ?></li>
          <?php endforeach; ?>
      </ul>

      <?php else: ?>
        Under Construction
      <?php endif; ?>
      </div>
      <div class="clear"></div>
    </section>
    <?php if(count($exps)>0): ?>
      <section>
        <div class="sectionTitle">
          <h1>Experience</h1>
        </div>
        <?php foreach($exps as $exp): ?>
          <p>
          <strong>  <?php echo e($exp->exp_name); ?></strong>,
          <small>  <?php echo e(\Carbon\Carbon::parse($exp->exp_start_date)->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::parse($exp->exp_start_date)->toFormattedDateString()); ?></small>
          </p>
        <?php endforeach; ?>

    </section>

    <?php endif; ?>
    <section>
      <div class="sectionTitle">
        <h1>Education</h1>
      </div>
    <div>
      <?php foreach($education as $edu ): ?>
          <strong><span class=""><?php echo e($edu->Degree_type); ?> in <?php echo e($edu->Degree_name); ?></span></strong>,<span class="smallpad"><?php echo e($edu->Degree_institute); ?></span><br>
          <strong>Passing Year: </strong> <span class="smallpad"><?php echo e($edu->Degree_end_date); ?> </span><strong> Result:</strong><span class="smallpad"><?php echo e($edu->Degree_result); ?></span><br><br>
      <?php endforeach; ?>
    </div>
  </section>

    <?php if(count($extras)>0): ?>
      <div class="sectionTitle">
          <h1>Extra Curricular</h1>
      </div>
      <div class="">
        <?php foreach($extras as $excc ): ?>
            <strong> <?php echo e($excc->excc_name); ?></strong><br>
            <strong>Description</strong>:
            <?php echo e($excc->excc_description); ?><br>
          <small><?php echo e(\Carbon\Carbon::parse($excc->excc_start_date)->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::parse($excc->excc_end_date)->toFormattedDateString()); ?></small><br>
        <?php endforeach; ?>
        <?php endif; ?>
        </div>

    <?php if(count($refs)>0): ?>
      <div class="sectionTitle">
        <h1>References</h1>
        </div>
      <div >
        <?php foreach($refs as $ref ): ?>
          <p >
            <strong>Referred By</strong> <?php echo e($ref->referred_by); ?><br>

            <small><strong>Contact : </strong><?php echo e($ref->referee_number); ?></small>
          </p>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>


          <div class="supersmall">
            <hr>
            <small>Gerenated by unigigg.com</small>
          </div>


</body>




</html>
