<?php $__env->startSection('content'); ?>

  <div class="pad padtop container">
    <div class="row">
      <div class="col-md-10 card">


        <table class="table pad">
          <thead>

              <th>
                Title
              </th>
              <th>
                Expiration Date
              </th>
              <th>
                Status
              </th>


          </thead>
          <?php foreach($jobs as $job): ?>
          <tbody>
            <tr>
              <td>
                <?php echo e($job->job_name); ?>

              </td>
              <td>
                <?php echo e($job->job_expires); ?>

              </td>
              <td>
                <?php if($job->status===0): ?>
                  Inactive
                  <form class="form-group" action="<?php echo e(url('/admin/status/activate',$job->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-sm raised btn-primary">
                      <i class="fa fa-check"></i> Change
                    </button>
                  </form>
                <?php else: ?>
                  Active
                  <form class="form-group" action="<?php echo e(url('/admin/status/inactivate',$job->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-sm raised btn-warning">
                      <i class="fa fa-check"></i> Change
                    </button>
                  </form>
                <?php endif; ?>

              </td>
            </tr>
          </tbody>
          <?php endforeach; ?>
        </table>


      </div>

    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>