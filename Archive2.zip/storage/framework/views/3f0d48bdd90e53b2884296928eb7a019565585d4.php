<!-- Hobbies-->
<div class="padsmall col-md-12" >
  <h4>Your Hobbies</h4>
  <?php if(count($hobbies)>0): ?>


  <?php foreach($hobbies as $hobby): ?>
    <p>
      <table class="table table-striped">
        <thead>
          <th>
            Hobby
          </th>
          <th>
            Things you have done regarding your hobby
          </th>
        </thead>
        <tbody>
          <tr>
            <td>
              <?php echo e($hobby->hobbies_name); ?>

            </td>
            <td>
              <?php echo e($hobby->hobbies_related_work); ?>

            </td>
            <td>
              <form action="<?php echo e(url('hobby',$hobby->hobbies_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-danger ">
                  <i class="fa fa-cross"></i> Delete
                </button>
              </form>

            </td>
          </tr>
        </tbody>
      </table>
    </p>

  <?php endforeach; ?>
<?php else: ?>
    <p>Nothing added</p>
<?php endif; ?>

</div>
