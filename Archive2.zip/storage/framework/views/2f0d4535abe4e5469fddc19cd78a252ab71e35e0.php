
<?php if(count($images)>0): ?>

    <img class="card-raised " src="<?php echo ('files/images/'.$images->filePath); ?>" alt="propic" height="150px" width="150px" />

<?php else: ?>
    <p>No Image Uploaded yet</p>
<?php endif; ?>
