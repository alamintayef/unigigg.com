<?php $__env->startSection('content'); ?>
<div class="container padtop">
  <div class="row">

<?php if(count($skill)>0): ?>
<div class="panel whiteproper pad">


<table class="table  table-hover" >
  <thead>

  <th>
    Name
  </th>
  <th>
    Status
  </th>
  <th>
    View Profile
  </th>
  </thead>
  <tbody>
    <?php foreach($skill as $skills): ?>
      <tr>

        <td><?php echo e($skills->name); ?></td>
        <td>
        <?php if($skills->verified===1): ?>
          <h5>verified</h5>
        <?php else: ?>
          not verified

        <?php endif; ?>
        </td>
        <td>

        <form class="form-control" action="<?php echo e(url('/aprofile',$skills->id)); ?>" method="GET">

          <button type="submit" class="btn btn-default btn-mini pull-right">view</button>

        </form>

      </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php else: ?>
  <p>
    Nothing found . . .
  </p>

<?php endif; ?>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>