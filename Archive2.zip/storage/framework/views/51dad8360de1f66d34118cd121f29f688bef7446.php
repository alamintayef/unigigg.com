<?php $__env->startSection('content'); ?>
  <div class="container padtop" id="chakri">
    <div class="row">

      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="col-md-10 " style="font-size:12px;">
        <div >
          <ul class="nav nav-pills panel whiteproper ">
                    <!--
            <li class="active"><a href="<?php echo e(url('chakri')); ?>">All</a></li>

            <li ><a href="<?php echo e(url('internships')); ?>">Internships</a></li>
            <li ><a href="<?php echo e(url('fulltime')); ?>">Full-Time</a></li>
            <li ><a href="<?php echo e(url('parttime')); ?>">Part-Time</a></li>
            <li ><a href="<?php echo e(url('onetime')); ?>">One-Time</a></li>
            -->
            
            <li><?php echo $__env->make('search.search',['url'=>'search/charki'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></li>
          </ul>
        </div>

          <table class="table table-responsive table-stripped  whiteproper card-raised padsmall">
            <thead>
              <tr>
                <th>Title</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Company</th>
                <th>View </th>
              </tr>
            </thead>
          <?php if(count($jobs)>0): ?>
            <?php foreach($jobs as $job): ?>


            <tbody>
            <tr>
              <td>
                <strong> <?php echo e($job->job_name); ?></td>
                <td>
                  <?php echo e($job->job_location); ?>

                </td>
                <td>
                   <?php echo e($job->job_salary); ?>

                </td>
                <td>
                <?php echo e($job->company_name); ?>


              </td>
              <td>
                  <a href="<?php echo e(url('show/jobs',$job->id)); ?>" class="btn btn-default">view</a>
              </td>
            </tr>

    </tbody>

        <?php endforeach; ?>

      <?php endif; ?>



    </table>


      </div>

    </div>
  </div>
    <script type="text/javascript">
    (function ($) {
      $('#chakri').smoothState();
   }) (jQuery);
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>