<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">

      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <div class="col-md-10">

          <?php if(count($job)>0): ?>
          <div class="panel">

          <h3 class="textb padsmall">Title: <?php echo e($job->job_name); ?></h3>
            </div>
            <div class="col-md-12">

              <div class="panel panel-primary">
                <div class="panel-heading">
                  Type: <?php echo e($job->job_type); ?>

                  <li>Location: <?php echo e($job->job_location); ?></li>
                  <li>Salary: <?php echo e($job->job_salary); ?></li>
                </div>
                <div class="panel-body ">
                  <p>
                    <strong>Description: </strong><?php echo $job->job_description; ?>

                  </p>
                  <hr>
                  <p>
                    <strong>Educational Requirements: </strong><?php echo e($job->min_edu_level); ?> / <?php echo e($job->major); ?> / <?php echo e($job->cgpa); ?>

                  </p>
                  <p>
                    <strong>  Additional Requirements: </strong>  <?php echo $job->job_reqs_additional; ?>

                  </p>
                  <p>
                    <strong>  Application Deadline: </strong>  <?php echo e($job->job_last_date_application); ?>

                  </p>
                </div>
                <div class="panel-footer">

                  <div class="well">
                    <strong>Posted By <?php echo e($job->company_name); ?></strong>

                    <!-- Check if its recruter or not-->
                    <?php if(Auth::user()->type===1): ?>
                      <form class="form-control" action="<?php echo e(url('apply')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                          <input type="hidden" name="applied_for_job_id" value="<?php echo e($job->id); ?>">
                        </div>
                        <div class="form-group">
                          <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        </div>

                        <?php if(count($applicable)>2): ?>
                          <?php if(Auth::user()->verified===0): ?>
                            <p class="text-danger">
                              You need to verify your profile to apply
                            </p>
                          <?php else: ?>
                              <?php if($reqMatch->Degree_result>=$job->cgpa): ?>
                                <button type="submit" name="submit" class="btn btn-success">Apply</button>
                              <?php else: ?>
                                <h6 class="text-danger">Sorry you do not fulfill the minimum job criteria</h6>
                              <?php endif; ?>
                          <?php endif; ?>


                        <?php else: ?>
                          <p class="text-danger">
                            Fill Profile information to apply to jobs
                          </p>

                        <?php endif; ?>


                      </form>
                    </div>
                  </div>
                <?php endif; ?>
              </div>

            </div>


        <?php endif; ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>