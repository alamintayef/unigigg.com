
<h4><?php echo e($data['name']); ?></h4>
<p>
  has just signed up. His email id is <?php echo e($data['email']); ?> <br>
  He has Signed up as <?php echo e($data['type']); ?> with password <?php echo e($data['password']); ?> and phone number : <?php echo e($data['phone']); ?>


</p>
