<?php $__env->startSection('content'); ?>

  <div class="container padtop pad">
    <div class="row">
      <div class="col-md-10 panel padsmall">
        <div class="col-md-4">
          <?php if(count($employer)>0): ?>


          <?php echo e($employer->company_name); ?> <br>
          <?php echo e($employer->company_phone); ?><br>
          <?php echo e($employer->company_description); ?><br>
          <?php echo e($employer->company_address); ?><br>
          <?php echo e($employer->company_type); ?><br>
          <?php echo e($employer->company_size); ?><br>
          <?php if($employer->subs_type===0): ?>
            <h6>Pay As you go</h6>

          <?php elseif($employer->subs_type===1): ?>
            <h6 class="textb">Subscribed to 10 jobs a year</h6>
          <?php else: ?>
            <h6>Corporate Bundle</h6>
          <?php endif; ?>
            <?php echo e($employer->expireson); ?><br>
          <?php if($employer->verified===0): ?>
            <button class="btn-danger">Not verified</button>
          <?php else: ?>
            <button class="btn-success">verified</button>
          <?php endif; ?>
        </div>

        <div class="col-md-6">
          <h4>Jobs Posted By <?php echo e($employer->company_name); ?></h4>
          <table class="table">
            <thead>
              <th>Postion</th>
              <th>Type</th>
              <th>Paid</th>
            </thead>

        <?php foreach($jobsposted as $posted): ?>
            <tbody>

            <td>
              <em><?php echo e($posted->job_name); ?></em>
            </td>
            <td>
          <em> <?php echo e($posted->job_type); ?></em>
            </td>
            <td>
              <?php if($posted->paid===1): ?>
                paid
            </td>
              <td>
              <?php else: ?>
                Not Yet
              </td>
            <?php endif; ?>

              </tbody>
                <?php endforeach; ?>
          </table>



        </div>



      </div>
    <?php else: ?>
      <div class="card card-raised">
        Nothing added
      <a href="<?php echo e(url('employerlist')); ?>"></a>
      </div>

    <?php endif; ?>

    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>