<?php $__env->startSection('content'); ?>


  <div class="container padtop ">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-7">
        <div class="well panel whiteproper" >
          <h4>Post A Job</h4>
          <?php if($postable>0): ?>
            Welcome
          <?php else: ?>
            <p class="text-danger">
              Please build company profile to post a job <a href="<?php echo e(url('employerinfo')); ?>"> Build Profile</a>
            </p>
          <?php endif; ?>
        </div>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
              <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php echo $__env->make('employer.postJobForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;


      </div>
      <div class="col-md-3  panel whiteproper pad">
        <h5>Your Jobs</h5>
        <?php foreach($postedjobs as $jobs): ?>
          <li id="list"><?php echo e($jobs->job_name); ?></li>

        <?php endforeach; ?>
        <small>Please visit <a href="<?php echo e(url('/postedjobs')); ?>">posted jobs</a> to view full job details</small>

      </div>
    </div>
  </div>

  <script src="//cdn.ckeditor.com/4.5.8/basic/ckeditor.js"></script>
  <script type="text/javascript">
   CKEDITOR.replace( 'job_reqs_additional' );
   CKEDITOR.replace( 'job_description' );

  </script>
  <script type="text/javascript">
    var major = document.getElementById("job_skill_reqs");
    var autocomplete=new Awesomplete(job_skill_reqs, {
    minChars: 1,
    autoFirst: true
    });
    autocomplete.list =['C', 'C++', 'JavaScript','MS-Office','Accounting','Python','Php','Laravel','NodeJs','HTML','Django','Java', 'ASP.NET','Marketing','Finance','Writing','Graphic Design','Web Design','Photo Shop','Adobe Suite','3D Modeling']

  </script>

  <script type="text/javascript">
  var cgpa = document.getElementById("cgpa");
  var autocompletecgpa=new Awesomplete(cgpa, {
  minChars: 1,
  autoFirst: true
  });
  autocompletecgpa.list = ['2','2.5','2.75','3','3.25','3.5']
  </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>