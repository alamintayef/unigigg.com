<div class="padsmall" >
  <h4>Your Skills</h4>
  <?php if(count($skill)>0): ?>


      <p>
        <table class="table table-bordered table-responsive " style="text-align:center;">
          <thead>
            <th>
              Skill
            </th>
            <th>
              Level
            </th>
            <th>
              Experience
            </th>

            <th>
              Skill Proof
            </th>
            <th>
              Verification
            </th>
            <th>
              Delete
            </th>

          </thead>
          <tbody>
            <?php foreach($skill as $skills): ?>
            <tr>
              <td>
                <?php echo e($skills->skill_name); ?>


              </td>
              <td>
                <?php echo e($skills->skill_level); ?>


              </td>
              <td>
                <?php echo e($skills->skill_experience); ?> Years
              </td>

                <?php if(count($skills->skill_proof)>0): ?>
                  <td>
                    <a href="<?php echo e($skills->skill_proof); ?>" target="_blank"><?php echo e($skills->skill_name); ?></a>
                  </td>
                <?php else: ?>
                  <td>
                    Not added
                  </td>
                <?php endif; ?>
                <?php if($skills->varified===0): ?>
                  <td>
                    Not Verified
                  </td>
                <?php else: ?>
                  <td>
                    Verified
                  </td>
                <?php endif; ?>
                <td>
                  <form action="<?php echo e(url('skill/delete',$skills->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-danger">
                      <i class="fa fa-trash fa-3x"></i>
                    </button>
                  </form>
                </td>
              </tr>
                <?php endforeach; ?>
            </tbody>
          </table>
        </p>


    <?php else: ?>
        <p>No Skills Added Yet</p>
      <p>
        You need to add a skill proof related to the skill. Before adding a skill please upload related document to google drive / github / onedrive / dropbox then share the link so that we can verfiy your skills and give feedback
      </p>


    </div>

  <?php endif; ?>
  <!-- Modal ends -->
