<?php $__env->startSection('content'); ?>
  <script type="text/javascript">
  (function ($) {
    $('#interest').smoothState();
 }) (jQuery);

  </script>
  <div class="container padtop" id="interest">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-7">

        <ul class="nav nav-pills panel whiteproper">
          <li ><a href="<?php echo e(url('userinfo')); ?>">Basic Information</a></li>
          <li ><a href="<?php echo e(url('image')); ?>">Profile Pic</a></li>
          <li ><a href="<?php echo e(url('edu')); ?>">Education</a></li>
          <li ><a href="<?php echo e(url('skill')); ?>">Skills</a></li>
          <li><a href="<?php echo e(url('experience')); ?>">Experience</a></li>
          <li><a href="<?php echo e(url('refs')); ?>">Reference</a></li>
          <li><a href="<?php echo e(url('excc')); ?>">Extra-Curricular</a></li>
          <li  class="active"><a href="<?php echo e(url('interest')); ?>">Upload CV</a></li>
            <li ><a href="<?php echo e(url('hobby')); ?>">Cover Letter</a></li>
          <li><a href="<?php echo e(url('fun')); ?>">About You</a></li>
            <li><a href="<?php echo e(url('vdoprofile')); ?>">Video Profile</a></li>

        </ul>


          <div class="well">

            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            <?php if(notify()->ready()): ?>
    <script>
        swal({
            title: "<?php echo notify()->message(); ?>",
            text: "<?php echo notify()->option('text'); ?>",
            type: "<?php echo e(notify()->type()); ?>",
            <?php if(notify()->option('timer')): ?>
                timer: <?php echo e(notify()->option('timer')); ?>,
                showConfirmButton: false
            <?php endif; ?>
        });
    </script>
<?php endif; ?>


            <?php echo $__env->make('student.forms.interest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      </div>
    </div>
    <div class="col-md-2 panel whiteproper">
      <h5 class="textb">Your CV Link</h5>
      <?php foreach($var as $interest): ?>
        <ul  class="list-group">
          <li id="list" class="list-group-item"><a href="<?php echo e($interest->interest_name); ?>">Your CV </a></li>
        </ul>
      <?php endforeach; ?>

    </div>
  </div>
</div>
<script type="text/javascript">
$("#loading").hide();
  var form = $('#cvform');
  var submit = $('#submit');
  var alert = $('.alert');// contact form
 $("#cvid").click(function (e) {
   $("#loading").show();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
            }
        })

        e.preventDefault();

$.ajax({
              url: 'interest/store',
              data: {'interest_name':$('input[name=interest_name').val(), '_token': $('input[name=_token]').val()},
              type: 'POST',
              datatype: 'JSON',
              success: function (data) {
                $("#loading").hide();
                alertify.success("Added Successfully");
                //  toastr.success(data);
                /*  toastr.options = {
                          "closeButton": true,
                          "debug": false,
                          "newestOnTop": false,
                          "progressBar": true,
                          "positionClass": "toast-bottom-right",

                }*/
                //  $('#list').html('<li>' +  data  +'</li>')
                  form.trigger('reset');

              },
              error: function (data) {
                console.log('Error:', data);
            }
          });
        });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>