<?php $__env->startSection('content'); ?>

<div class="container padtop">
<div class="panel pad">

<form  action="" method="POST">
    <?php echo csrf_field(); ?>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <?php foreach($errors->all() as $error): ?>
        <p><?php echo e($error); ?></p>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <input type="hidden" name="" value="<?php echo e($jobs->id); ?>" id="id">
  <div class="form-group">
    <?php echo Form::label('job_name', 'Tltle:'); ?><span class="text-danger">*</span>
    <?php echo Form::text('job_name', $jobs->job_name, ['class'=>'form-control']); ?>

  </div>

  <div class="form-group">
    <label for="job_type">Job Type</label>
    <select class="form-control" id="select" name="job_type">
      <option value="Internship">Internship</option>
      <option value="OneTime">One-Time</option>
      <option value="PartTime">Part-Time</option>
      <option value="FullTime">Full-Time</option>

    </select>
  </div>
  <div class="form-group">
    <?php echo Form::label('job_salary', 'Salary Offering:'); ?><span class="text-danger">*</span>
    <?php echo Form::text('job_salary',$jobs->job_salary , ['class'=>'form-control'] ); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('job_location', 'Location:', ['class' => 'control-label']); ?>

    <input name="job_location" value="<?php echo e($jobs->job_location); ?>" class="awesomplete form-control" list="arealist" />
    <datalist id="arealist">
      <?php foreach($area as $areas): ?>
        <option><?php echo e($areas->area); ?></option>
      <?php endforeach; ?>
    </datalist>

      <small class="text-danger">Required</small>
    </div>
    <div class="form-group">
      <p>
        <strong>Current Job Description</strong> <br>
        <?php echo $jobs->job_description; ?>

      </p>

    </div>
    <div class="form-group">
      <?php echo Form::label('job_description', 'Job Description:'); ?><span class="text-danger">*</span>
      <?php echo Form::textarea('job_description', null, ['class'=>'form-control', 'rows'=>4, 'id'=> 'job_description'] ); ?>

      <small class="ssmal">Describe what the job is all about. e.g. Responsibilities</small>
    </div>

  <hr>
  <div class="form-group">
    <?php echo Form::label('min_edu_level', 'Minimum Degree Level:', ['class' => 'control-label']); ?>

    <input name="min_edu_level" value="<?php echo e($jobs->min_edu_level); ?>" class="awesomplete form-control" list="levellist" data-multiple  />
    <datalist id="levellist">
     <option>Bachelors</option>
     <option>Masters</option>
     <option>HSC</option>
     <option>Graduating Soon</option>
   </datalist>
    <small class="ssmal">e.g. Bachelors, Masters, PHD</small>
  </div>


  <div class="form-group">
    <?php echo Form::label('major', 'Major:', ['class' => 'control-label']); ?>

    <input name="major" id='major' value="<?php echo e($jobs->major); ?>" class="awesomplete form-control" />

    <script type="text/javascript">
        var major = document.getElementById("major");
        var autocompletemajor=new Awesomplete(major, {
        minChars: 1,
        autoFirst: true
        });
          autocompletemajor.list =['Computer Science', 'Business Administration', 'Economics','Mathemtics']
    </script>
    <small class="text-danger">Required</small>
    </div>
    <div class="form-group">
      <?php echo Form::label('cgpa', 'Minimum CGPA:', ['class' => 'control-label']); ?>

      <input name="cgpa" id='cgpa' value="<?php echo e($jobs->cgpa); ?>" class="awesomplete form-control" />

      <small class="text-danger">Required</small>
      </div>
      <script type="text/javascript">
        var cgpa = document.getElementById("cgpa");
        var autocompletecgpa=new Awesomplete(cgpa, {
        minChars: 1,
        autoFirst: true
        });
        autocompletecgpa.list = ['2','2.5','2.75','3','3.25','3.5']
      </script>
  <hr>
  <div class="form-group">
    <?php echo Form::label('job_skill_reqs', 'Skill Requirments:'); ?><span class="text-danger">*</span>
  <input name="job_skill_reqs" value="<?php echo e($jobs->job_skill_reqs); ?>" id='job_skill_reqs' class="awesomplete form-control" data-multiple  />
    <small class="ssmal">Insert the specific skill set you are looking for. e.g. MS-Office, Php, Java, Accounting</small>
  </div>
  <script type="text/javascript">
    var input = document.getElementById("job_skill_reqs");
    var autocomplete=new Awesomplete(input, {
    minChars: 1,
    autoFirst: true,
    filter: function(text, input) {
      return Awesomplete.FILTER_CONTAINS(text, input.match(/[^,]*$/)[0]);
    },

    replace: function(text) {
      var before = this.input.value.match(/^.+,\s*|/)[0];
      this.input.value = before + text + ", ";
    }
});
autocomplete.list =['C', 'C++', 'JavaScript','MS-Office','Accounting','Python','Php','Laravel','NodeJs','HTML','Django','Java', 'ASP.NET','Marketing','Finance','Writing','Graphic Desing','Web Design'

  </script>
  <div class="form-group">
    <p>
      <strong>Current Additional Requirments</strong> <br>
      <?php echo $jobs->job_reqs_additional; ?>

    </p>

  </div>
  <div class="form-group">
        <?php echo Form::label('job_reqs_additional', 'Additional Requirments: '); ?>

        <?php echo Form::textarea('job_reqs_additional',null , ['class'=>'form-control', 'rows'=>3,'id'=> 'job_reqs_additional'] ); ?>

        <small class="ssmal">If you have and specific additional requirments</small>
      </div>
  <div class="form-group">
    <?php echo Form::label('job_start_date', 'Commencing Date:'); ?>

    <?php echo Form::date('job_start_date', $jobs->job_start_date, ['class'=>'form-control'] ); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('job_last_date_application', 'Last Date Of Application'); ?>

    <?php echo Form::date('job_last_date_application', $jobs->job_last_date_application, ['class'=>'form-control'] ); ?>

  </div>
  <?php if(Auth::user()->subs_type!=0): ?>
    <input type="hidden" name="paid" value="1">
  <?php else: ?>
      <input type="hidden" name="paid" value="0">
  <?php endif; ?>

  <div class="form-group">
      <i id='loading' class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
      <?php echo Form::submit('Update', array( 'class'=>'btn btn-info job_post' )); ?>

  </div>
</form>

</div>

</div>
<script src="//cdn.ckeditor.com/4.5.8/basic/ckeditor.js"></script>
<script type="text/javascript">
  CKEDITOR.replace( 'job_reqs_additional' );
  CKEDITOR.replace( 'job_description' );

</script>

<script type="text/javascript">
  $("#loading").hide();
</script>
<script type="text/javascript">


$(".job_post").click(function (e) {
   var task_id = $("#id").val();
  $("#loading").show();
$.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
    }
  })
  e.preventDefault();
$.ajax({
    url: 'postjobs/update'+ id,
    data: {
      '_token': $('input[name=_token]').val(),
      'job_name':$('input[name=job_name]').val(),
      'job_type':$('select[name=job_type]').val(),
      'job_salary':$('input[name=job_salary]').val(),
      'job_location':$('input[name=job_location]').val(),
      'job_description':$('textarea[name=job_description]').val(),
      'min_edu_level':$('input[name=min_edu_level]').val(),
      'major':$('input[name=major]').val(),
      'cgpa':$('input[name=cgpa]').val(),
      'job_skill_reqs':$('input[name=job_skill_reqs]').val(),
      'job_reqs_additional':$('textarea[name=job_reqs_additional]').val(),
      'job_start_date':$('input[name=job_start_date]').val(),
      'job_last_date_application':$('input[name=job_last_date_application]').val()
      'paid':$('input[name=paid]').val()

    },
    type: 'POST',
    datatype: 'JSON',
    success: function (name) {
      $("#loading").hide();
      alertify.success("Added Successfully");
    //  $('#list').append('<li><strong>' +  name  +'</strong></li>')
      document.getElementById('postForm').reset();

  },
  error: function (name) {
    console.log('Error:', name);
  }
});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>