<?php $__env->startSection('content'); ?>
<div class="container padtop">
<div class="row">

<div class="col-md-10">

    <div class="col-md-3">

    </div>
    <div class="col-md-8 ">
  <div class="card-raised whiteproper pad">
    <h4>Set Appointment </h4>
    <small>Admin Will Notify all the candidates for you.</small>

    <?php echo Form::open(array('url' => 'payment/call/for/interview')); ?>

      <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
          <?php foreach($errors->all() as $error): ?>
            <p><?php echo e($error); ?></p>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php if(notify()->ready()): ?>
        <script>
        swal({
          title: "<?php echo notify()->message(); ?>",
          text: "<?php echo notify()->option('text'); ?>",
          type: "<?php echo e(notify()->type()); ?>",
          <?php if(notify()->option('timer')): ?>
          timer: <?php echo e(notify()->option('timer')); ?>,
          showConfirmButton: false
          <?php endif; ?>
        });
        </script>
      <?php endif; ?>
    <div class="form-group">
      <?php echo Form::label('appointment', 'Appointment Date:', ['class' => 'control-label']); ?>

      <?php echo Form::date('appointment', \Carbon\Carbon::now(), ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('appoint_time', 'Time:', ['class' => 'control-label']); ?>

      <?php echo Form::text('appoint_time', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('identifier', 'Bkash Number:', ['class' => 'control-label']); ?>

      <?php echo Form::text('identifier', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('transaction_id', 'Transaction ID:', ['class' => 'control-label']); ?>

      <?php echo Form::text('transaction_id', null, ['class' => 'form-control']); ?>

    </div>
    <input type="hidden" name="id" value="<?php echo e($job->id); ?>">


  <?php echo Form::submit('Confirm', ['class' => 'btn btn-primary']); ?>


  <?php echo Form::close(); ?>

  </div>
  </div>
  </div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>