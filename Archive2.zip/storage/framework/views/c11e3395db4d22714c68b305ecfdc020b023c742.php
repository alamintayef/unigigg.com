<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">
      <div class="panel padsmall">


      <table class="table table-responsive table-striped">
        <thead>
          <th>
          Request By
          </th>
          <th>
          Requested for
          </th>
          <th>
          Number
          </th>
          <th>
            Appointment Date and Time
          </th>
          <th>
            Bkash Number
          </th>
          <th>
            Transaction Number
          </th>
          <th>
            Call
          </th>
        </thead>
        <?php foreach($interviewcall as $calls): ?>
          <tbody>
          <tr>
            <td>
              <?php echo e($calls->company_name); ?>

            </td>
            <td>
              <?php echo e($calls->job_name); ?>


            </td>
            <td>
              <?php echo e($calls->company_phone); ?>

            </td>
            <td>
              <?php echo e($calls->appointment); ?> and <?php echo e($calls->appoint_time); ?>

            </td>
            <td>
              <?php echo e($calls->identifier); ?>

            </td>
            <td>
              <?php echo e($calls->transaction_id); ?>

            </td>
            <td>
              <?php if($calls->paid===0): ?>
                <form  action="<?php echo e(url('call/for/interview',$calls->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-default btn-sm">
                  <i class="fa fa-phone"></i> Notify
                </button>
              </form>
              <?php else: ?>
                Already Notified

              <?php endif; ?>

            </td>
          <?php endforeach; ?>
        </table>
    </div>
    </div>
<?php echo $__env->make('errors.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>