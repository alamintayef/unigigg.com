<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row ft ">
      <a href="<?php echo e(url('home')); ?>"><h4 class="text-primary"><i class="fa fa-arrow-left"></i> Go Back </h4></a>
      <div >
            <ul class="nav nav-pills panel whiteproper nav-justified">
              <li ><a href="<?php echo e(url('eccentricJobs')); ?>">All</a></li>
              <li ><a href="<?php echo e(url('tuitions')); ?>">Tutions</a></li>
              <li class="active"><a href="<?php echo e(url('assignements')); ?>">Assignments</a></li>
              <li ><a href="<?php echo e(url('others')); ?>">Others</a></li>
              <li><?php echo $__env->make('search.search',['url'=>'searchassignment'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></li>
            </ul>
      </div>
      <?php if(count($assignements)>0): ?>

        <?php foreach($assignements as $jobs): ?>
          <div class="col-md-3 col-md-offset-1 textb whiteproper panel padsmall">
          <fieldset>
              <h6><?php echo e($jobs->title); ?></h6>

            <div class="textb">
              <strong><?php echo e($jobs->type); ?></strong>
              <p>
                <?php echo e($jobs->description); ?>

              </p>
              <strong><?php echo e($jobs->offering); ?></strong>/
              <strong><?php echo e($jobs->area); ?></strong>



              <?php if(Auth::user()->id!=$jobs->user_id): ?>
                <form class="form-inline" action="<?php echo e(url('apply/eccentric')); ?>" method="post">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                      <input type="hidden" name="applied_for_odd_id" value="<?php echo e($jobs->odd_id); ?>">
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                  </div>
                  <?php if(Auth::user()->type===2): ?>
                  <small class="text-warning">  Sorry Recruiters cannot apply to jobs</small>
                  <?php else: ?>


                  <?php if(count($applicable)>0): ?>
                        <button type="submit" name="button" class="btn btn-success btn-sm">Apply</button>
                  <?php else: ?>
                    <p class="text-danger">
                      Please fill profile information to apply
                    </p>
                  <?php endif; ?>
                  <?php endif; ?>
                  <p>

                  <?php if($jobs->user_id===Auth::user()->id): ?>
                    You posted this job
                  <?php else: ?>

                    Posted By  <?php echo e($jobs->user_id); ?>

                  <?php endif; ?>
                  </p>
                </form>
            <?php endif; ?>



            </div>
          </fieldset>
          </div>
        <?php endforeach; ?>

      <?php endif; ?>


    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>