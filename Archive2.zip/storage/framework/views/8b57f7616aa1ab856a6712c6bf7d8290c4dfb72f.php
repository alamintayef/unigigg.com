<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6 whiteproper panel">

        <h2 class="textb">Post Eccentric Jobs</h2>
<style media="screen">

</style>
        <?php echo Form::open(array('url' => '/eccentricJobspost')); ?>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
              <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <div class=" pad">
          <div class="form-group">
            <?php echo Form::label('title', 'Job Title:', ['class' => 'control-label']); ?>

            <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

          </div>
          <div class="form-group">

            <label for="type">Catagory</label>
            <select class="form-control" id="select" name="type">
              <option value="Tution">Tuition</option>
              <option value="Assignment">Assignment Help</option>
              <option value="Research Assistant">Research Assistant</option>
              <option value="Photography">Photo Graphy</option>
              <option value="Other">Other</option>
            </select>

          </div>
          <div class="form-group">
            <?php echo Form::label('description', 'Job Description:', ['class' => 'control-label']); ?>

            <?php echo Form::textarea('description', null, ['class' => 'form-control', 'rows'=>2]); ?>

          </div>
          <div class="form-group">

            <label for="type">Offering(TK):</label>
            <select class="form-control" id="select" name="offering">
              <option value="1000">1000</option>
              <option value="1000-3000">1000-3000</option>
              <option value="3000-5000">3000-5000</option>
              <option value="5000-10000">5000-10000</option>
            </select>

          </div>
          <div class="form-group">
            <?php echo Form::label('area', 'Location:', ['class' => 'control-label']); ?>

            <br>
            <!--  <?php echo Form::text('area', null, ['class' => 'form-control']); ?>-->
            <input name="area" class="form-control" list="arealist" />
            <datalist id="arealist">
              <?php foreach($area as $areas): ?>
                <option><?php echo e($areas->area); ?></option>
              <?php endforeach; ?>
            </datalist>
          </div>
          <div class="form-group">
            <label for="university" class="control-label">University</label><br>
            <input name="university" class="form-control " list="unilist" />
            <datalist id="unilist">
              <?php foreach($uni as $unis): ?>
                <option><?php echo e($unis->university); ?></option>
              <?php endforeach; ?>
            </datalist>
          </div>
          <div class="form-group">
            <?php echo Form::submit('Post Job', array( 'class'=>'btn btn-success form-control' )); ?>

          </div>
          <?php echo Form::close(); ?>

        </div>
      </div>
      <div class="col-md-3 col-sm-offset-1 whiteproper panel">

        <h4 >Instructions</h4 >
          <p>

          </p>

        </div>
        <div class="col-md-3 col-xs-offset-1 center panel whiteprope pad">
          <h5>Jobs Posted By You</h5>

          <?php foreach($postedjobs as $jobs): ?>
            <?php echo e($jobs->title); ?><br>


          <?php endforeach; ?>



        </div>
      </div>
    </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>