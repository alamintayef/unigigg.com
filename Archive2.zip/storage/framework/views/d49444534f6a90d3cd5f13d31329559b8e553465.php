<!DOCTYPE html>
<html lang="en">

  <body>


     <h4><?php echo e(( $info['fname'])); ?> <?php echo e(($info['lname'] )); ?></h4>
    <p>

      Has applied to <strong> <?php echo e(($info['job_name'] )); ?></strong>

    </p>

  </body>
</html>
