<div class="padsmall" >


  <p>
    <?php if(count($infos)>0): ?>


        <p>

            You Have Applied to :  <?php echo e(count($joblimit)); ?> jobs <br>
            You Have Applied to :  <?php echo e(count($oddjoblimit)); ?> Eccentric jobs
          <hr>
          <h6>Phone : <?php echo e($infos->mobile); ?></h6>
          <h6>Institute: <?php echo e($infos->institute); ?></h6>
          <h6>NID : <?php echo e($infos->NId); ?></h6>
        </p>
        <p>
        <h5>University ID :<?php echo e($infos->universityId); ?></h5>
        Facebook: Id:
        <a href="<?php echo e($infos->facebookId); ?>" target="_blank"><?php echo e($infos->fname); ?></a><br>
      <a class="btn btn-default raised  " href="<?php echo e(url('userinfo')); ?>"> <i class="fa fa-edit"></i>Edit Info</a></div>

          <hr>
          <form class="form-inline" action="<?php echo e(url('pdf')); ?>" method="get">
            <?php echo csrf_field(); ?>

            <button type="submit" class="btn btn-info raised ">
              <i class="fa fa-tasks"></i> Generate CV
            </button>

          </form>
          <hr>


<?php else: ?>
    <p>Please add you profile information from <a href="<?php echo e(url('userinfo')); ?>">Build profile</a> Tab</p>
  <?php endif; ?>
        <a class="btn btn-default" href="<?php echo e(url('/profile',$user->name)); ?>"> Public Resume 1</a>
        <a class="btn btn-default" href="<?php echo e(url('profile/template',$user->name)); ?>">Public Resume 2</a>



  </p>

</div>
