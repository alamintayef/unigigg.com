<?php $__env->startSection('content'); ?>


<div class="container padtop">
		<div class="row">
			<div class="[ col-xs-12 col-sm-offset-2 col-sm-8 ]">

				<?php foreach($training as $trainings): ?>
				<div class="panel panel-primary ">

					<div class="panel-heading">
						<div class="panel-title textw">
								<h3 class="textw"><?php echo e($trainings->title); ?></h3>
						</div>
					</div>
						<div class="panel-body">

							<?php echo e($trainings->description); ?>

							<hr>

								Competition starts on :	<?php echo e($trainings->training_start_date); ?><span class="pull-right"> Application Deadline : <?php echo e($trainings->application_dead_line); ?></span>


						</div>

			</div>

		<?php endforeach; ?>
			</div>
		</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>