<div class=" col-md-12" style="font-size:13px;">


  <h4>Education</h4>
  <?php foreach($education as $edu): ?>
    <div class="panel panel-default">

      <div class='panel-heading'>
        <h4 class="panel-title"> Degree:    <?php echo e($edu->Degree_name); ?></h4>
        <strong>Type:</strong>  <?php echo e($edu->Degree_type); ?>

      </div>
      <div class="panel-body">

        <strong>Institute</strong> <?php echo e($edu->Degree_institute); ?>

        <strong>Result:</strong>  <?php echo e($edu->Degree_result); ?>

        <strong> Starting Year : </strong> <?php echo e($edu->Degree_start_date); ?>

        <strong> Passing Year: </strong>  <?php echo e($edu->Degree_end_date); ?>

        <form class="pull-right" action="<?php echo e(url('edupdate',$edu->id)); ?>" method="GET">
          <?php echo csrf_field(); ?>

          <button type="submit" class="btn btn-sm btn-primary" >
            <i class="fa fa-edit"></i>
          </button>
        </form>
        <form class="pull-right" action="<?php echo e(url('edudel',$edu->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <button type="submit" class="btn btn-raised btn-danger btn-sm">
            <i class="fa fa-trash"></i>
          </button>
        </form>
      </div>

      <div class="panel-footer padsmall">




      </div>


    </div>



    <!-- Modal ends -->
  <?php endforeach; ?>
</div>
