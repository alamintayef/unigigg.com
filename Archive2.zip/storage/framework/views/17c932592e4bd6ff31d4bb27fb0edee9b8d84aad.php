<?php $__env->startSection('content'); ?>
  <div class="container padtop" id="applied">
    <div class="row">
    <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10">
        <div class="panel whiteproper padsmall">
          <h4 class="textb">Applied Candidates</h4>
          <button type="button" Class="btn btn-default pull-right" name="button">Sort <i class="fa fa-search"></i></button>
          <a href="<?php echo e(url('view/applied')); ?>">Go Back</a>
        </div>


        <?php foreach( $applied as $seek ): ?>
          <?php if($seek->user_id===Auth::user()->id): ?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <?php if($seek->paid!=0): ?>
                <h4><?php echo e($seek->fname); ?> <?php echo e($seek->lname); ?></h4>
              <?php else: ?>
              Candidate ID :  <?php echo e($seek->id); ?>

              <?php endif; ?>


            </div>
            <div class="panel-body">


              <p class="col-md-4">
                <strong >Applied for</strong> : <?php echo e($seek->job_name); ?> <br>
                <strong>Institute</strong>: <?php echo e($seek->institute); ?> <br>
              </p>


            </div>

            <div class="panel-footer">


              <p class="inline">

                <?php if(Auth::user()->subs_type!=0): ?>
                  <form class="pull-right" action="<?php echo e(url('/talent/profile/paid',$seek->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-info">
                      <i class="fa fa-user"></i> view profile
                    </button>
                  </form>
                <?php else: ?>
                  <form class="pull-right" action="<?php echo e(url('/talent/profile',$seek->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-info">
                      <i class="fa fa-user"></i> view profile
                    </button>
                  </form>
                <?php endif; ?>

                <form class="pull-right" action="<?php echo e(url('/remove/applied',$seek->applied_id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-Trash"></i> Remove
                  </button>
                </form>

              <?php if($seek->already===0): ?>
                  <form action="<?php echo e(url('shortlist')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="user_id" value="<?php echo e($seek->id); ?>">
                    <input type="hidden" name="shortlisted_for_job_id" value="<?php echo e($seek->job_id); ?>">
                    <input type="hidden" name="shortlistedby" value="<?php echo e(Auth::user()->id); ?>">
                    <button type="submit" class="btn btn-primary ">
                      <i class="fa fa-bookmark"></i> Shortlist
                    </button>
                  </form>
              <?php else: ?>
                  <h6 class="textb">Already Shortlisted</h6>
              <?php endif; ?>

              </p>


            </div>

          </div>
         <?php endif; ?>

        <?php endforeach; ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
  <script type="text/javascript">

  (function ($) {
  $('#applied').smoothState();
})(jQuery);

  </script>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>