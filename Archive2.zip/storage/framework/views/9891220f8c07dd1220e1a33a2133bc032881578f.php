<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Resume</title>
<?php echo Html::style('css/blue.css'); ?>

<!--[if IE 7]>
<link href="css/ie7.css" rel="stylesheet" type="text/css" />
<![endif]-->
<!--[if IE 6]>
<link href="css/ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->

<?php echo Html::script('js/jquery-1.4.2.min.js'); ?>

<?php echo Html::script('js/jquery.tipsy.js'); ?>

<?php echo Html::script('js/cufon.yui.js'); ?>

<?php echo Html::script('js/scrollTo.js'); ?>

<?php echo Html::script('js/myriad.js'); ?>

<?php echo Html::script('js/jquery.colorbox.js'); ?>

<?php echo Html::script('js/custom.js'); ?>


<script type="text/javascript">
		Cufon.replace('h1,h2');
</script>
</head>
<body>
<!-- Begin Wrapper -->
<div id="wrapper">
  <div class="wrapper-top"></div>
  <div class="wrapper-mid">
    <!-- Begin Paper -->
    <div id="paper">
      <div class="paper-top"></div>
      <div id="paper-mid">
        <div class="entry">
          <!-- Begin Image -->
					<?php if(count($image)>0): ?>
						<img class="portrait" src="<?php echo ('/files/images/'.$image->filePath); ?>" alt="John Smith" />
					<?php endif; ?>
          <!-- End Image -->
          <!-- Begin Personal Information -->
          <div class="self">
            <h1 class="name"><?php echo e($info->fname); ?> <?php echo e($info->lname); ?> <br/>
              <!--<span>Interactive Designer</span>--></h1>
            <ul>
              <li class="ad"> <?php echo e($info->area); ?></li>
              <li class="mail"> <?php echo e($user->email); ?></li>
              <li class="tel"> Confidential</li>

            </ul>
          </div>
          <!-- End Personal Information -->
          <!-- Begin Social --
          <div class="social">
            <ul>
              <li><a class='north' href="#" title="Download.pdf"><img src="../sysimg/icn-save.jpg" alt="Download the pdf version" /></a></li>
              <li><a class='north' href="javascript:window.print()" title="Print"><img src="sysimg/icn-print.jpg" alt="" /></a></li>
              <li><a class='north' id="contact" href="contact/index.html" title="Contact Me"><img src="sysimg/icn-contact.jpg" alt="" /></a></li>
              <li><a class='north' href="#" title="Follow me on Twitter"><img src="sysimg/icn-twitter.jpg" alt="" /></a></li>
              <li><a class='north' href="#" title="My Facebook Profile"><img src="sysimg/icn-facebook.jpg" alt="" /></a></li>
            </ul>
          </div>
          <!-- End Social -->
        </div>
        <!-- Begin 1st Row -->
        <div class="entry">
          <h2>OBJECTIVE</h2>
					<?php if(count($about)!=0): ?>
							<?php echo $about->fun_facts; ?>

					<?php else: ?>
						<p>
							I haven't added anything Yet
						</p>
					<?php endif; ?>
				</div>
        <!-- End 1st Row -->
        <!-- Begin 2nd Row -->
				<?php if(count($edu)>0): ?>


        <div class="entry">
          <h2>EDUCATION</h2>
					<?php foreach($edu as $education): ?>
          <div class="content">
            <h3><?php echo e($education->Degree_start_date); ?> to <?php echo e($education->Degree_end_date); ?></h3>
            <p><?php echo e($education->Degree_institute); ?><br />
              <em><?php echo e($education->Degree_type); ?> in <?php echo e($education->Degree_name); ?></em></p>
          </div>
				<?php endforeach; ?>

        </div>
					<?php endif; ?>
        <!-- End 2nd Row -->
        <!-- Begin 3rd Row -->
				<?php if(count($exp)>0): ?>


        <div class="entry">
          <h2>EXPERIENCE</h2>
          <div class="content">
						<?php foreach($exp as $x): ?>
							<h3><?php echo e(\Carbon\Carbon::parse($x->exp_start_date)->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::parse($x->exp_start_date)->toFormattedDateString()); ?></h3>
  					<p>
							<?php echo e($x->exp_name); ?>

              </p>

					<?php endforeach; ?>

          </div>

					<!--
          <div class="content">
            <h3>Jun 2007 - May 2009</h3>
            <p>Junior Web Designer <br />
              <em>Bachelor of Science in Graphic Design</em></p>
            <ul class="info">
              <li>Sed fermentum sollicitudin interdum. Etiam imperdiet sapien in dolor rhoncus a semper tortor posuere. </li>
              <li>Pellentesque at lectus in libero dapibus cursus. Sed arcu ipsum, varius at ultricies acuro, tincidunt iaculis diam.</li>
            </ul>
          </div>
				-->
        </div>
						<?php endif; ?>
        <!-- End 3rd Row -->
        <!-- Begin 4th Row -->
        <div class="entry">
          <h2>SKILLS</h2>
          <div class="content">
            <h3>Software Knowledge</h3>
            <ul class="skills">
							<?php foreach($skills as $skill): ?>
		            <li><a href="<?php echo e($skill->skill_proof); ?>"> <?php echo e($skill->skill_name); ?></a></li>
		          <?php endforeach; ?>
            </ul>
          </div>
					<!---
          <div class="content">
            <h3>Languages</h3>
            <ul class="skills">
              <li>CSS/XHTML</li>
              <li>PHP</li>
              <li>JavaScript</li>
              <li>Ruby on Rails</li>
              <li>ActionScript</li>
              <li>C++</li>
            </ul>
          </div>
				-->
        </div>
        <!-- End 4th Row -->
         <!-- Begin 5th Row --
        <div class="entry">
        <h2>WORKS</h2>
        	<ul class="works">
        		<li><a href="images/1.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/2.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/3.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/1.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/2.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/3.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/1.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        		<li><a href="images/1.jpg" rel="gallery" title="Lorem ipsum dolor sit amet."><img src="images/image.jpg" alt="" /></a></li>
        	</ul>
        </div>
        <!-- Begin 5th Row -->
      </div>
      <div class="clear"></div>
      <div class="paper-bottom"></div>
    </div>
    <!-- End Paper -->
  </div>
  <div class="wrapper-bottom"></div>
</div>
<div id="message"><a href="#top" id="top-link">Go to Top</a></div>
<!-- End Wrapper -->
</body>
</html>
