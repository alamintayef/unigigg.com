<?php $__env->startSection('content'); ?>
  <script type="text/javascript">
  (function ($) {
    $('#ref').smoothState();
 }) (jQuery);

  </script>
  <div class="container padtop" id="ref">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-7">

        <ul class="nav nav-pills panel whiteproper">
          <li ><a href="<?php echo e(url('userinfo')); ?>">Basic Information</a></li>
          <li ><a href="<?php echo e(url('image')); ?>">Profile Pic</a></li>
          <li ><a href="<?php echo e(url('edu')); ?>">Education</a></li>
          <li ><a href="<?php echo e(url('skill')); ?>">Skills</a></li>
          <li ><a href="<?php echo e(url('experience')); ?>">Experience</a></li>
          <li class="active"><a href="<?php echo e(url('refs')); ?>">Reference</a></li>
          <li ><a href="<?php echo e(url('excc')); ?>">Extra-Curricular</a></li>
          <li ><a href="<?php echo e(url('interest')); ?>">Upload CV</a></li>
            <li ><a href="<?php echo e(url('hobby')); ?>">Cover Letter</a></li>
          <li><a href="<?php echo e(url('fun')); ?>">About You</a></li>
            <li><a href="<?php echo e(url('vdoprofile')); ?>">Video Resume</a></li>

        </ul>


          <div class="well">

            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
            <?php if(notify()->ready()): ?>
              <script>
              swal({
                title: "<?php echo notify()->message(); ?>",
                text: "<?php echo notify()->option('text'); ?>",
                type: "<?php echo e(notify()->type()); ?>",
                <?php if(notify()->option('timer')): ?>
                timer: <?php echo e(notify()->option('timer')); ?>,
                showConfirmButton: false
                <?php endif; ?>
              });
              </script>
            <?php endif; ?>


            <?php echo $__env->make('student.forms.ref', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      </div>
    </div>
    <div class="col-md-2 panel whiteproper">
      <h5 class="textb">References from</h5>
      <?php foreach($var as $refs): ?>
        <ul class="list-group">
          <li class="list-group-item"><?php echo e($refs->referred_by); ?></li>
        </ul>
      <?php endforeach; ?>

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>