<?php $__env->startSection('content'); ?>

  <div class="pad padtop container">
    <div class="row">
      <div class="col-md-10 card">


        <table class="table pad">
          <thead>

              <th>
                Title
              </th>

              <th>
                Status
              </th>


          </thead>
          <?php foreach($blogs as $blog): ?>
          <tbody>
            <tr>
              <td>
                <?php echo e($blog->title); ?>

              </td>

              <td>
                <?php if($blog->status===0): ?>
                  Inactive
                  <form class="form-group" action="<?php echo e(url('/admin/blog/status/activate',$blog->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-sm raised btn-primary">
                      <i class="fa fa-check"></i> Change
                    </button>
                  </form>
                <?php else: ?>
                  Active
                  <form class="form-group" action="<?php echo e(url('/admin/status/inactivate',$blog->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-sm raised btn-warning">
                      <i class="fa fa-check"></i> Change
                    </button>
                  </form>
                <?php endif; ?>

              </td>
              <td>
                <form class="form-group" action="<?php echo e(url('blog/edit',$blog->id)); ?>" method="GET">

                  <button type="submit" class="btn btn-sm raised btn-warning">
                    <i class="fa fa-check"></i> Update
                  </button>
                </form>
              </td>
            </tr>
          </tbody>
          <?php endforeach; ?>
        </table>


      </div>

    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>