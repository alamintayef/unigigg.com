
<div class="container padtop">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10" id="font">
      <div class="card card-raised padsmall">
        <div class="panel-heading"><h4 class="textb">Dashboard</h4></div>

    <?php echo $__env->make('errors.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <div class="col-md-12">
            <div class="col-md-8 pull-left">
                <h4>Welcome onboard <strong><?php echo e(Auth::user()->name); ?></strong></h4>
            </div>
          </div>

          <div class="col-md-12">
            <div class="col-md-4 pull-right">
                <?php echo $__env->make('student.partials.userview.imageview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-4 pull-left">
              <?php if(Auth::user()->verified===0): ?>
                <h5 class="text-danger">Not Verified</h5>
              <?php else: ?>
                <h5 class="text-success">Verified</h5>
              <?php endif; ?>

              <br>
              <h3>
              <?php if(count($infos)>0): ?>
                <?php if(count($skill)>0): ?>
                  <?php if(count($education)>0): ?>
                  <a class="btn btn-success raised btn-sm " href="<?php echo e(url('verify/me')); ?>"><i class="fa fa-btn fa-check-square-o"></i>Verify Profile</a></h3>
                  <?php endif; ?>
                <?php endif; ?>
              <?php endif; ?>
              <?php if(Auth::user()->subs_type===0): ?>
              <?php else: ?>
                <button type="button" name="button" class="btn-default btn-lg">Subscribed for 6 months</button>
              <?php endif; ?>

            </div>
            <br>


          </div>
          <div class="col-md-12 pad">
            <?php echo $__env->make('student.partials.userview.vview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>



          <br>

          <div class="col-md-12 panel whiteproper">
        <h3 class="padsmall textb">Your Details</h3>
          <?php echo $__env->make('student.partials.userview.infoview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php if(count($education)>0): ?>
            <?php echo $__env->make('student.partials.userview.eduview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>

      <?php echo $__env->make('student.partials.userview.skillview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('student.partials.userview.expview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('student.partials.userview.interestview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('student.partials.userview.exccview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('student.partials.userview.referenceview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('student.partials.userview.funview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>




</div>
</div>





</div>
</div>
