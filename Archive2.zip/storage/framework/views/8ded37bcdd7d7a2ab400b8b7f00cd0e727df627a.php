<?php $__env->startSection('content'); ?>
  <script type="text/javascript">
  (function ($) {
    $('#hobby').smoothState();
 }) (jQuery);

  </script>
  <div class="container padtop" id="hobby">
    <div class="row">

      <div class="col-md-10">

      <div class="well">

            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
        <?php echo $__env->make('errors.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="panel panel-default">
          <div class="panel-heading">Create a Post</div>

          <div class="panel-body">

        <form class="form-group" action="<?php echo e(url('blog/update',$post->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>

        <small class="text-danger">Every field is required</small>
        <div class="form-group">
          <?php echo e($post->title); ?>

          <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

          <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo e($post->subtitle); ?>

          <?php echo Form::label('subtitle', 'Sub Title:', ['class' => 'control-label']); ?>

          <?php echo Form::text('subtitle', null, ['class' => 'form-control']); ?>

        </div>

        <div class="form-group">
          <?php echo $post->body; ?>

          <?php echo Form::label('body', 'Write Post:', ['class' => 'control-label']); ?>

          <?php echo Form::textarea('body', null, ['class' => 'form-control' ,'rows'=>'10','id'=>'post']); ?>

        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
        </div>
      <?php endif; ?>



        <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


     <?php echo Form::close(); ?>


    </div>
    </div>


    <script type="text/javascript">
     CKEDITOR.replace( 'post' );


    </script>


      </div>
    </div>

  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>