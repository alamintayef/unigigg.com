<title>User Board</title>
<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">
      <div class="card card-raised">
        <div class=" padsmall">


        <?php echo Form::open(['method'=>'GET','url'=>'search/manush','class'=>'form-inline']); ?>

          <input type="text" class="form-control" name="search" placeholder="Search...">
          <button class="btn btn-default" type="submit">
            <i class="fa fa-search"></i>
            </button>
        <?php echo Form::close(); ?>

        </div>
        <table class="table table-striped table-responsive">
          <thead>
            <th>
              Name
            </th>
            <th>
              Email
            </th>
            <th>
              Profile
            </th>
            <th>
              Verification
            </th>
            <th>
              Delete
            </th>
            <th>
              Point
            </th>
          </thead>
          <tbody>
            <?php foreach($alluser as $users): ?>
              <tr>
                <td>
                  <?php echo e($users->name); ?>

                </td>
                <td>
                  <?php echo e($users->email); ?>

                </td>
                <td>
                  <form  action="<?php echo e(url('/aprofile',$users->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-primary">
                      <i class="fa fa-user"></i>
                    </button>
                  </form>
                </td>

                <td>
                  <?php if($users->verified===0): ?>
                    <button type="button" name="button" class="btn-danger">Not Verified</button>
                  <?php else: ?>
                      <i class="fa fa-check-circle fa-2x"></i>
                  <?php endif; ?>
                </td>
                <td>
                  <form  action="<?php echo e(url('admin/delete/user',$users->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <button type="submit" class="btn btn-danger">
                      <i class="fa fa-trash"></i>
                    </button>
                  </form>
                </td>
                <td>
                  <?php echo e($users->profile_count); ?>

                </td>

              </tr>

            <?php endforeach; ?>

            <?php echo e($alluser->links()); ?>




          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php echo $__env->make('errors.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>