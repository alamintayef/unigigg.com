<?php $__env->startSection('content'); ?>


<div class="container padtop">
		<div class="row">
      <div class="col-md-8 panel whiteproper pad">
        <h2>Add Competiton</h2>
      <?php echo Form::open(array('url' => '/add/competition/create')); ?>



      <div class="form-group">
        <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('description', 'Description:', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('event_date', 'Event Date:', ['class' => 'control-label']); ?>

        <?php echo Form::date('event_date', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('last_date_of_application', 'Deadline:', ['class' => 'control-label']); ?>

        <?php echo Form::date('last_date_of_application', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('competition_link', 'Competition URL', ['class' => 'control-label']); ?>

        <?php echo Form::text('competition_link', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('organized_by', 'Organizer', ['class' => 'control-label']); ?>

        <?php echo Form::text('organized_by', null, ['class' => 'form-control']); ?>

      </div>


      <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


      <?php echo Form::close(); ?>



    </div>
    <div class="col-md-3 col-md-offset-1 panel padsmall">

      <h3>Added So Far</h3>
      <?php if(count($competition)>0): ?>
        <?php foreach($competition as $com): ?>
          <?php echo e($com->title); ?>


          <button type="submit" name="button"> <i class="fa fa-edit"></i></button></form> <form class="" action="index.html" method="post"><button type="submit" ><i class="fa fa-close"></i></button></form>

        <?php endforeach; ?>

      <?php endif; ?>

    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>