<?php $__env->startSection('content'); ?>
<style media="screen">
body
{
  background: url(http://www.jsrent.com/wp-content/uploads/2015/03/job-hunting.jpg) no-repeat center center fixed;
  -webkit-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
</style>

<div class="container padtop">
  <div class="row pad">

    <div class="col-md-12 " style="font-size:14px; padding:5px">
      <div class="transparentbg" >
        <ul class="">
          <!--
          <li class="active"><a href="<?php echo e(url('jobs/view')); ?>"><strong class="textw">Regular Jobs</strong></a></li>
          <li><a href="<?php echo e(url('jobs/view/eccentric')); ?>"><strong class="textw">Eccentric Jobs </strong></a></li>
        -->
          <li class="textw"><?php echo $__env->make('search.search',['url'=>'search/jobs'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></li>
        </ul>
      </div>
      <hr>
      <table class="table table-responsive table-stripped   whiteproper card-raised padsmall">
        <thead>
          <tr>
            <th>Title</th>
            <th>Location</th>
            <th>Salary</th>
            <th>Company</th>
            <th>View </th>
          </tr>
        </thead>
      <?php if(count($jobs)>0): ?>
        <?php foreach($jobs as $job): ?>

          <!---
          <div class="col-md-3 col-md-offset-1">
            <div class="card-container">
              <div class="card">
                <div class="front">

                  <div class="cover">

                    <img src="http://photos.gograph.com/thumbs/CSP/CSP894/k8940822.jpg" alt="logo" height="100px" width="100px"/>

                  </div>
                --
              <div class="content">
                <div class="main">
                  <h3 class="name"> <?php echo e($job->job_name); ?> </h3>
                  <p class="profession"> Type: <?php echo e($job->job_type); ?></p>

                  <p class="text-center">  <br>Location: <?php echo e($job->job_location); ?>

                    <br>Salary: <?php echo e($job->job_salary); ?><br>

                    <strong>Posted By <?php echo e($job->company_name); ?></strong><br>
                    <strong>Posted on <?php echo e($job->created_at); ?></strong>
                  </p>
                </div>
                <div class="footer">
                  <div class="rating">
                    <i class="fa fa-mail-forward"></i> Auto Rotation
                  </div>
                </div>
              </div>
            </div> <!-- end front panel --
            <div class="back">
              <div class="header">
                <h5 class="motto">"To be or not to be, this is my awesome motto!"</h5>
              </div>
              <div class="content">
                <div class="main">
                  <h4 class="text-center">Job Description</h4>
                  <p class="textb text-center">
                    please click view to see the full job description
                  </p>
                  <p class="text-center"><?php echo e($job->job_expires); ?>.</p>

                  <div class="stats-container">
                    <form class="form-control" action="<?php echo e(url('/view/jobs',$job->slug)); ?>" method="GET">

                      <button type="submit" class="btn btn-default btn-mini pull-right">view</button>

                    </form>
                  </div>

                </div>
              </div>
              <div class="footer">

              </div>
            </div> <!-- end back panel --
          </div> <!-- end card --
        </div> <!-- end card-container -






        <!-- Check if its recruter or not--





      </div>
    -->

        <tbody>
        <tr>
          <td>
            <strong> <?php echo e($job->job_name); ?></td>
            <td>
              <?php echo e($job->job_location); ?>

            </td>
            <td>
              <?php echo e($job->job_salary); ?>

            </td>
            <td>
            <strong><?php echo e($job->company_name); ?></strong>

          </td>
          <td>
              <a href="<?php echo e(url('/view/jobs',$job->slug)); ?>" class="btn btn-default">view</a>

          </td>
        </tr>

</tbody>

    <?php endforeach; ?>

  <?php endif; ?>



</table>
</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>