<?php $__env->startSection('content'); ?>
<style media="screen">
.pl
{
    padding: 10px;
}
.ft{ font-size: 13px;}
.td {
  width:150px;
  }
  </style>

  <div class="container padtop" id="svp">
    <div class="row">
      <?php if(Auth::user()->type==2): ?>
        <a href="<?php echo e(URL::previous()); ?>">Go Back</a>
      <?php elseif(Auth::user()->type==1): ?>
        <a href="<?php echo e(url('home')); ?>">Go Back</a>
      <?php else: ?>
        <a href="<?php echo e(url('admin')); ?>">Go Back</a>
      <?php endif; ?>

      <div class="col-md-10">

        <div class="panel panel-blue" >
          <div class="panel-heading">
              <div class="pull-right pl">
                <?php foreach($images as $image): ?>
                <img src="<?php echo ' /files/images/'.$image->filePath; ?>" alt="propic" height="100px" width="100px" style="border-radius:50%;" />
              <?php endforeach; ?>
              <br>
              <br>

                <?php if($user->verified===1): ?>
                  <h6 class="text-success">
                    Verified
                  </h6>
                <?php else: ?>
                  <h6 class="text-danger">
                    Not Verified
                  </h6>
                <?php endif; ?>

            </div>
              <?php foreach($profile as $view ): ?>
              <h3 class="textb"><?php echo e($view->fname); ?> <?php echo e($view->lname); ?></h3>

            </div>
            <div class="panel-body ft pl">
              <div>

                <p>
                <b>  University:</b> <b> <?php echo e($view->institute); ?> </b><br> <b>  Contact:</b> <b> <?php echo e($view->mobile); ?> </b>
                <br>
                <?php echo e($view->area); ?>

                <br>
                Facebook Profile : <a href="<?php echo e($view->facebookId); ?>"><?php echo e($view->fname); ?> <?php echo e($view->lname); ?></a><br>
                CV : <a href="<?php echo e($cv->interest_name); ?>">CV of <?php echo e($view->fname); ?> </a>

                </p>

              </div>
            <?php endforeach; ?>

            <h4>Skills</h4>
            <table class="table">
              <thead>
                <tr>

                  <th>Skill Name</th>
                  <th>Skill Level</th>
                  <th>Skill Proof</th>

                </tr>
              </thead>
              <tbody>
                <?php foreach($skill as $skills): ?>
                  <tr>

                    <td><?php echo e($skills->skill_name); ?></td>
                    <td><?php echo e($skills->skill_level); ?></td>
                    <td><a href="<?php echo e($skills->skill_proof); ?>"> <?php echo e($skills->skill_name); ?></a></td>

                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <h4>Education</h4>

            <?php foreach($education as $edu ): ?>
              <div class="panel panel-default">

                <div class='panel-heading'>
                  <h4 class="panel-title"> <strong>Degree:</strong>  <?php echo e($edu->Degree_name); ?></h4>
                  <strong>Type:</strong>  <?php echo e($edu->Degree_type); ?>

                </div>
                <div class="panel-body">
                  <strong>Institute</strong><span class="pl"> <?php echo e($edu->Degree_institute); ?></span>
                  <strong>Results</strong> <span class="pl"> <?php echo e($edu->Degree_result); ?></span>
                  <strong> Start Date: </strong><span class="pl"> <?php echo e($edu->Degree_start_date); ?></span>
                  <strong> Passing Date: </strong><span class="pl"><?php echo e($edu->Degree_end_date); ?></span>
                </div>



              <?php endforeach; ?>

            </div>
            <hr>
            <h4 class="pl">Experiences</h4>
            <div class="pl">
                <?php foreach($exps as $exp ): ?>
                  <hr>
            <p class="pl">
              <strong>Title:</strong> <?php echo e($exp->exp_name); ?><br>
              <strong>Description</strong>:<br>
                <?php echo e($exp->exp_description); ?><br>
              <small><strong>start date :</strong></small> <?php echo e($exp->exp_start_date); ?> <small><strong>end date :</strong></small> <?php echo e($exp->exp_end_date); ?>

            </p>
            <?php endforeach; ?>
          </div>
          <h4 class="pl">References</h4>
          <div class="pl" >
            <?php foreach($refs as $ref ): ?>
        <p>
          <strong>Referred By</strong> <?php echo e($ref->referred_by); ?><br>
          <strong>Description</strong>:<br>
            <?php echo e($ref->reference_description); ?><br>
          <small><strong>Contact : </strong><?php echo e($ref->referee_number); ?></small>  </p>
        <?php endforeach; ?>

          </div>



          </div>
          <!--

          <div class="panel-footer">
            <button type="button" name="button">Shortlist</button>
          </div>
        </div>
      -->

      </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>