
      <div class="panel-body panel whiteproper">

      <?php echo Form::open(array('url' => '/imagestore','files'=>true)); ?>




      <div class="form-group">
          <?php echo Form::label('filePath', 'Choose profile Image'); ?>

          <?php echo Form::file('filePath', array('class'=>'btn btn-info form-control')); ?>

      </div>

      <div class="form-group">
          <?php echo Form::submit('upload', array( 'class'=>'btn btn-success ' )); ?>

      </div>



      <?php echo Form::close(); ?>

      </div>
