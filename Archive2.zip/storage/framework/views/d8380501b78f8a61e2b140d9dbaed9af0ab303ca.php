

    <div class="panel panel-default">
    <div class="panel-body">

    <?php echo Form::open(array('url' => '/interest/store','id'=>'cvform')); ?>



    <div class="form-group">
      <h4>Upload you CV/Resume in GoogleDrive/Dropbox and share the link here.</h4>
      <?php echo Form::label('interest_name', 'Your CV or Resume Link', ['class' => 'control-label']); ?>

      <?php echo Form::text('interest_name', null, ['class' => 'form-control']); ?>

    </div>


    <i id='loading' class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
    <span class="sr-only">Loading...</span>
    <?php echo Form::submit('Add', ['class' => 'btn btn-info','id'=>'cvid']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
