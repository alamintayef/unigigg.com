<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <?php echo Html::style('css/css/demo.css'); ?>

    <?php echo Html::style('css/css/material-kit.css'); ?>

    <?php echo Html::style('css/css/bootstrap.min.css'); ?>

    <?php echo Html::script('css/js/material-kit.js'); ?>

    <?php echo Html::script('css/js/material.min.js'); ?>

    <?php echo Html::script('css/js/bootstrap-datepicker.js'); ?>

    <?php echo Html::script('css/js/bootstrap.min.js'); ?>


    <style media="screen">
    body{
        background-color:#f7f7f7;
    }
      .top{
        padding-top: 100px;
      }
    </style>

  </head>
  <body>


    <div class="container padtop top">
      <div class="row">



        <h3>Welcome <strong class="primary"><?php echo e(Auth::user()->name); ?>

        </strong> Super admin</h3>
        <?php if(count($errors)>0): ?>
          <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
              <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

      <div class="col-sm-4 panel col-sm-offset-1">

          <ul class="list-group">
          <li class="list-group-item"><a href="<?php echo e(url('verification')); ?>">Show Verification Request</a</li>
           <li class="list-group-item"><a href="<?php echo e(url('area')); ?>">Add area</a></li>
           <li class="list-group-item"><a href="<?php echo e(url('managejobs')); ?>">Cron Jobs</a></li>
           <li class="list-group-item"><a href="<?php echo e(url('manage/odd/jobs')); ?>">Eccentric Cron Jobs</a></li>
           <li class="list-group-item"><a href="<?php echo e(url('call/for/in')); ?>">Call For interview Request</a></li>
           <li class="list-group-item"><a href="<?php echo e(url('admin')); ?>">User board</a> <span class="badge"> <?php echo e($allusers); ?></span></li>
           <li class="list-group-item"><a href="<?php echo e(url('admin/job/board')); ?>">Job board</a></li>
           <li class="list-group-item"><a href="<?php echo e(url('admin/blog/board')); ?>">Blogs</a></li>
           <li class="list-group-item">Total Eccentric Jobs : <?php echo e(count($allOddJobs)); ?></li>
           <li class="list-group-item">Total Jobs : <?php echo e(count($allJobs)); ?></li>
          <li class="list-group-item"><a href="<?php echo e(url('addvdo')); ?>">Add video</a</li>
          <li class="list-group-item"><a href="<?php echo e(url('add/competition')); ?>">Add Competition</a</li>
          <li class="list-group-item"><a href="<?php echo e(url('add/training')); ?>">Add Training</a</li>
           <li class="list-group-item"><a href="<?php echo e(url('employerlist')); ?>">Employer board</a><span class="badge"> <?php echo e($allemployer); ?> </span></li>

           <li class="list-group-item">
             <div class="form-group label-floating">


             <?php echo Form::open(['method'=>'GET','url'=>'search','class'=>'form-inline']); ?>

             <label class="control-label">Seach</label>
               <input type="text" class="form-control " name="search">
               <button class="btn btn-default-sm" type="submit">
                 <i class="fa fa-search"></i>
                 </button>
             <?php echo Form::close(); ?>

             </div>
           </li>
           <li class="list-group-item"><a href="<?php echo e(url('adduniversity')); ?>">Add University</a> <span class="badge"><?php echo e($uni); ?></span></li>
           <li class="list-group-item"><a href="<?php echo e(url('Admin/Email')); ?>">Email</a></li>
          </ul>


      </div>
      <div class="col-md-4 card-raised col-md-offset-1 whiteproper">
        <a href="<?php echo e(url('admin/create/user')); ?>" class="btn btn-link"><i class="fa fa-plus"></i> Create <i class="fa fa-user"></i></a>

      </div>

        <?php if(notify()->ready()): ?>
          <script>
          swal({
            title: "<?php echo notify()->message(); ?>",
            text: "<?php echo notify()->option('text'); ?>",
            type: "<?php echo e(notify()->type()); ?>",
            <?php if(notify()->option('timer')): ?>
            timer: <?php echo e(notify()->option('timer')); ?>,
            showConfirmButton: false
            <?php endif; ?>
          });
          </script>
        <?php endif; ?>



    </div>
    </div>


  </body>
</html>
