<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">
      <?php if(Auth::user()->type===1): ?>
          <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php else: ?>
          <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>

      <div class="col-md-10">
        <div class="well">
          <h4 class="text-info">Applied Candidates</h4>
        </div>

        <?php foreach( $applied as $seek ): ?>
          <?php if($seek->user_id===Auth::user()->id): ?>
          <div class="panel padsmall">
            <h4><?php echo e($seek->fname); ?> <?php echo e($seek->lname); ?></h4> <strong >Applied for</strong> : <h6><?php echo e($seek->title); ?></h6>


                <strong>Institute</strong>: <?php echo e($seek->institute); ?>



                <div class="pull-right col-md-2">
                  <form  action="<?php echo e(url('eccentricjobswhoapplieddelete',$seek->o_a_id)); ?>" method="post">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger btn-block btn-sm">
                    <i class="fa fa-trash-o"></i> Delete
                  </button>
                </form>
                  <form  action="<?php echo e(url('talent/profile/eccentric',$seek->id)); ?>" method="GET">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-info btn-block btn-sm ">
                    <i class="fa fa-user"></i> Profile
                  </button>
                </form>


                </div>
                <br>
                <?php if($seek->called===0): ?>
                  <form  action="<?php echo e(url('/callforodd',$seek->o_a_id)); ?>" method="GET">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-default btn-sm ">
                    <i class="fa fa-phone"></i> Call for interview
                  </button>
                  <small><em>Pressing call for interview will notify the candidate and send them your number</em></small>
                </form>
                <?php else: ?>
                  Already Notified
                <?php endif; ?>

            </div>
          <?php endif; ?>

    <?php endforeach; ?>
          </div>



      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>