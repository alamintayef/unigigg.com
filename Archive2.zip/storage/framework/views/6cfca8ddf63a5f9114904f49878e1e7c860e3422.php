<?php $__env->startSection('content'); ?>
<div class="container padtop">
  <div class="row">




<?php if(count($skill)>0): ?>

<table class="table  table-hover" >
  <thead>
  
  <th>
    Skills
  </th>
  <th>
    User Name
  </th>
  </thead>
  <tbody>
    <?php foreach($skill as $skills): ?>
      <tr>
        <td>
          <?php echo e($skills->skill_name); ?>

        </td>
        <td>
          <?php echo e($skills->skill_experience); ?>

        </td>
        <td><?php echo e($skills->name); ?></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php else: ?>
  <p>
    Nothing found . . .
  </p>

<?php endif; ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>