
 <?php if(count($userinfo)>0): ?>
          <?php echo Form::open(array('url' => '/userstore')); ?>

          <div class="md-col-12 panel whiteproper pad">
          <div class="row">

          <div class="col-md-6">


          <div class="form-group">

            <?php echo Form::label('fname', 'First Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('fname',  $userinfo->fname , ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('lname', 'Last Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('lname', $userinfo->lname, ['class' => 'form-control']); ?>

            <small class="text-danger">Required</small>
          </div>
        </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('area', 'Location:', ['class' => 'control-label']); ?>

            <?php echo Form::text('area', $userinfo->area, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
            </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('post_code', 'Post Code', ['class' => 'control-label']); ?>

            <?php echo Form::text('post_code', $userinfo->post_code, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          </div>
          </div>
          <div class="form-group">
            <?php echo Form::label('other', 'Other Details (if any)', ['class' => 'control-label']); ?>

            <?php echo Form::text('other', $userinfo->other, ['class' => 'form-control']); ?>

            <small class="text-danger">Optional</small>
          </div>
          <div class="form-group">
            <label for="institute" class="control-label">Institute</label>
            <?php echo Form::text('institute', $userinfo->institute, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('passing_date', 'Expected/Passing Year :', ['class' => 'control-label']); ?>


            <?php echo Form::date('passing_date', $userinfo->passing_date, ['class' => 'form-control','id'=>'passing_date']); ?>



              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('mobile', 'Contact No :', ['class' => 'control-label']); ?>

            <?php echo Form::text('mobile', $userinfo->mobile, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('universityId', 'University ID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('universityId', $userinfo->universityId, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('NId', 'NID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('NId', $userinfo->NId, ['class' => 'form-control', 'placeholder'=>'17 digits']); ?>

              <small class="text-danger">Optional</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('facebookId', 'Facebook ID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('facebookId', $userinfo->facebookId, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
            <small>Please use the full link like http://www.facebook.com/yourid</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('LinkedInId', 'LinkedIn ID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('LinkedInId',$userinfo->LinkedInId, ['class' => 'form-control']); ?>

            <small class="text-danger">Optional</small>
          </div>




          <?php echo Form::submit('Add', ['class' => 'btn btn-primary btn-raised']); ?>



          <?php echo Form::close(); ?>



          <?php else: ?>

          <?php echo Form::open(array('url' => '/userstore')); ?>

          <div class="md-col-12 panel whiteproper pad">
          <div class="row">

          <div class="col-md-6">

          <div class="form-group">


            <?php echo Form::label('fname', 'First Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('fname',  null , ['class' => 'form-control', 'required']); ?>

              <small class="text-danger">Required</small>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('lname', 'Last Name', ['class' => 'control-label']); ?>

            <?php echo Form::text('lname', null, ['class' => 'form-control', 'required']); ?>

            <small class="text-danger">Required</small>
          </div>
        </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('area', 'Location:', ['class' => 'control-label']); ?>

            <input name="area" class="form-control" list="arealist" />
            <datalist id="arealist">
              <?php foreach($area as $areas): ?>
                <option><?php echo e($areas->area); ?></option>
              <?php endforeach; ?>
            </datalist>

              <small class="text-danger">Required</small>
            </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
            <?php echo Form::label('post_code', 'Post Code', ['class' => 'control-label']); ?>

            <?php echo Form::text('post_code', null, ['class' => 'form-control', 'required']); ?>

              <small class="text-danger">Required</small>
          </div>
          </div>
          </div>
          <div class="form-group">
            <?php echo Form::label('other', 'Other Details (if any)', ['class' => 'control-label']); ?>

            <?php echo Form::text('other', null, ['class' => 'form-control', ]); ?>

            <small class="text-danger">Optional</small>
          </div>
          <div class="form-group">
            <label for="institute" class="control-label">Institute</label>
          <input name="institute" class="form-control" list="unilist" />
              <datalist id="unilist">
              <?php foreach($uni as $unis): ?>

                <p value="<?php echo e($unis->university); ?>"><?php echo e($unis->university); ?></p>

                <?php endforeach; ?>
              </datalist>
              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('passing_date', 'Expected/Passing Year :', ['class' => 'control-label']); ?>

            <?php echo Form::date('passing_date', null, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('mobile', 'Contact No :', ['class' => 'control-label', 'required']); ?>

            <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('universityId', 'University ID:', ['class' => 'control-label', 'required']); ?>

            <?php echo Form::text('universityId', null, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('NId', 'NID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('NId', null, ['class' => 'form-control', 'placeholder'=>'17 digits']); ?>

              <small class="text-danger">Optional</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('facebookId', 'Facebook ID:', ['class' => 'control-label', 'required']); ?>

            <?php echo Form::text('facebookId', null, ['class' => 'form-control']); ?>

              <small class="text-danger">Required</small>
            <small>Please use the full link like http://www.facebook.com/yourid</small>
          </div>
          <div class="form-group">
            <?php echo Form::label('LinkedInId', 'LinkedIn ID:', ['class' => 'control-label']); ?>

            <?php echo Form::text('LinkedInId',null, ['class' => 'form-control']); ?>

            <small class="text-danger">Optional</small>
          </div>

          <?php echo Form::submit('Add', ['class' => 'btn btn-primary btn-raised']); ?>



          <?php echo Form::close(); ?>


  <?php endif; ?>

  <script type="text/javascript">
  $('.datepicker').datepicker({
weekStart:1
format:'dd/mm/yyyy'
});
  </script>
