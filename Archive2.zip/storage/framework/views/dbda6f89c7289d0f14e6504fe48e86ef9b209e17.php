<?php $__env->startSection('content'); ?>
  <style media="screen">
  #font{
    font-family: 'Courier';


  }

  </style>

<div class="container center padtop" id="font">
  <div class="row">
    <div class="col-lg-12 padsmall">
        <?php foreach($blog as $blogs): ?>
      <div class="panel col-md-10 col-md-offset-1">


        <h4><a href="<?php echo e(url('/blog/article',$blogs->slug)); ?>"><?php echo e($blogs->title); ?></a></h4>
        <h5><?php echo e($blogs->subtitle); ?></h5>



      </div>

      <?php endforeach; ?>
    </div>

  </div>

</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>