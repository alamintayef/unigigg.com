<?php $__env->startSection('content'); ?>
<div class="container padtop">
  <div class="row">




<?php if(count($skill)>0): ?>

<table class="table  table-hover" >
  <thead>
    <th>
      Job Name
    </th>
    <th>
      Skills Required
    </th>

  </thead>
  <tbody>
    <?php foreach($skill as $skills): ?>
      <tr>
        <td><?php echo e($skills->job_name); ?></td>
        <td>
          <?php echo e($skills->job_skill_reqs); ?>

        </td>
        <td>
          <form class="form-control" action="<?php echo e(url('/view/jobs',$skills->slug)); ?>" method="GET">

            <button type="submit" class="btn btn-default btn-mini pull-right">view</button>

          </form>
        </td>

      </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php else: ?>
  <p>
    Nothing found . . .
  </p>

<?php endif; ?>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>