<?php $__env->startSection('content'); ?>
  <script type="text/javascript">
  (function ($) {
    $('#email').smoothState();
 }) (jQuery);

  </script>
  <div class="container padtop" id="email">
    <div class="row">

      <div class="col-md-12">

      <div class="well">

            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
        <?php echo $__env->make('errors.notify', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="panel panel-default">
      <div class="panel-heading">Create a Email</div>

      <div class="panel-body">

    <?php echo Form::open(array('url' => 'admin/email/send')); ?>


        <small class="text-danger">Email</small>
        <div class="form-group">
          <?php echo Form::label('Subject', 'Subject:', ['class' => 'control-label']); ?>

          <?php echo Form::text('subject', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('subtitle', 'Sub Title:', ['class' => 'control-label']); ?>

          <?php echo Form::text('subtitle', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('body', 'Body :', ['class' => 'control-label']); ?>

          <?php echo Form::textarea('body', null, ['class' => 'form-control' ,'rows'=>'10','id'=>'post']); ?>

        </div>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
        </div>
      <?php endif; ?>



        <?php echo Form::submit('Send', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>

<script type="text/javascript">
 CKEDITOR.replace( 'post' );


</script>

      </div>
    </div>

  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>