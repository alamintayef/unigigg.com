<div class="padsmall col-md-12">

  <h4>About you</h4>
  <!--about your self -->


  <?php foreach($funs as $fun): ?>
    <p>
      <?php echo $fun->fun_facts; ?>

    </p>
    <p>
      <?php echo $fun->inspiration_qot; ?>

    </p>
    <p>
      <?php echo e($fun->Why_you); ?>

    </p>
    <p>
      <?php echo e($fun->Why_not_you); ?>

    </p>

  <?php endforeach; ?>

</div>
