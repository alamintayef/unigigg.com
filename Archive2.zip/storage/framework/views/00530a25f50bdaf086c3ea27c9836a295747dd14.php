<!DOCTYPE html>
<html>
  <?php if(count($info)>0): ?>
<head>

<title><?php echo e($info->fname); ?> <?php echo e($info->lname); ?></title>

<meta name="viewport" content="width=device-width"/>
<meta name="description" content="Resume from unigigg.com."/>
<meta charset="UTF-8">

  <?php echo Html::style('css/cvOne.css'); ?>



<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Rokkitt:400,700|Lato:400,300' rel='stylesheet' type='text/css'>

<!--[if lt IE 9]>
<script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<!--
<body id="top">
  <a href="https://www.facebook.com/sharer/sharer.php?u=www.unigigg.com/profile/<?php echo e($user->name); ?>" target="_blank">
  <button type="button" class="btn btn-link" name="button"><i class="fa fa-facebook"></i>Share <i class="fa fa-share"></i></button>
</a>
-->
<div id="cv" class="instaFade">
	<div class="mainDetails">
    <?php if(count($image)>0): ?>
      <div id="headshot" class="quickFade">
  		<img class="card-raised " src="<?php echo ('/files/images/'.$image->filePath); ?>" alt="propic" height="150px" width="150px" />
  		</div>
    <?php endif; ?>


		<div id="name">
			<h2 class="quickFade delayTwo"><?php echo e($info->fname); ?> <?php echo e($info->lname); ?></h2>


		</div>

		<div id="contactDetails" class="quickFade delayFour">
			<ul>
				<li><i class="fa fa-envelope"></i>: <?php echo e($user->email); ?></li>
        	<li><i class="fa fa-map-marker"></i>: <?php echo e($info->area); ?></li>
				<li><i class="fa fa-phone"></i>: Confidential</li>
			</ul>
		</div>
		<div class="clear"></div>
	</div>

	<div id="mainArea" class="quickFade delayFive">
		<section>
			<article>
				<div class="sectionTitle">
					<h1>About Me</h1>
				</div>

				<div class="sectionContent">
          <?php if(count($about)!=0): ?>
              <?php echo $about->Why_you; ?>

          <?php else: ?>
            <p>
              I haven't added anything Yet
            </p>
          <?php endif; ?>

				  </div>
			</article>
			<div class="clear"></div>
		</section>

		<section>
			<div class="sectionTitle">
				<h1>Education</h1>
			</div>
      <?php if(count($edu)>0): ?>


			<div class="sectionContent">
				<?php foreach($edu as $education): ?>

	      <article>
					<h2><?php echo e($education->Degree_type); ?> in <?php echo e($education->Degree_name); ?></h2>
					<p class="subDetails"><?php echo e($education->Degree_institute); ?></p>
					<p>Start : <?php echo e($education->Degree_start_date); ?> Passing : <?php echo e($education->Degree_end_date); ?>

						Result:<?php echo e($education->Degree_result); ?>

					</p>
				</article>
					<?php endforeach; ?>
        <?php else: ?>
          Under Construction
        <?php endif; ?>

			</div>
			<div class="clear"></div>
		</section>


		<section>
			<div class="sectionTitle">
				<h1>Work Experience</h1>
			</div>

			<div class="sectionContent">
				<article>
          <?php foreach($exp as $x): ?>
            <h2><?php echo e($x->exp_name); ?></h2>
            <p class="subDetails"><?php echo e(\Carbon\Carbon::parse($x->exp_start_date)->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::parse($x->exp_start_date)->toFormattedDateString()); ?></p>
            <p><?php echo e($x->exp_description); ?></p>
          <?php endforeach; ?>

				</article>

			</div>
			<div class="clear"></div>
		</section>


		<section>
			<div class="sectionTitle">
				<h1>Key Skills</h1>
			</div>
      <?php if(count($skills)>0): ?>

			<div class="sectionContent">
				<ul class="keySkills">
          <?php foreach($skills as $skill): ?>
            <li><a href="<?php echo e($skill->skill_proof); ?>"> <?php echo e($skill->skill_name); ?></a></li>
          <?php endforeach; ?>

				</ul>

      <?php else: ?>
        Under Construction
      <?php endif; ?>
			</div>
			<div class="clear"></div>
		</section>
    <section>
      <div class="sectionTitle">
        <h1>Extra Curricular Activities</h1>
      </div>

      <div class="sectionContent">
        <article>
          <?php foreach($extra as $xtra): ?>
            <h2><?php echo e($xtra->excc_name); ?></h2>
            <p class="subDetails"><?php echo e(\Carbon\Carbon::parse($xtra->excc_start_date)->toFormattedDateString()); ?> - <?php echo e(\Carbon\Carbon::parse($xtra->excc_end_date)->toFormattedDateString()); ?></p>
            <p><?php echo e($xtra->excc_description); ?></p>
          <?php endforeach; ?>

        </article>

      </div>
      <div class="clear"></div>
    </section>
    <section>
      <div class="sectionTitle">
        <h1>References</h1>
      </div>

      <div class="sectionContent">
        <article>
          <?php foreach($ref as $reference): ?>
            <h2><?php echo e($reference->referred_by); ?></h2>
            <p class="subDetails"><?php echo e($reference->reference_description); ?></p>
            <p><?php echo e($reference->referee_number); ?></p>
          <?php endforeach; ?>

        </article>

      </div>
      <div class="clear"></div>
    </section>




	</div>
</div>

</body>
  <?php else: ?>
    <p>
      Nothing Added Yet
    </p>
  <?php endif; ?>
</html>
