<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">

      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="col-md-10 " style="font-size:12px;">
        <div >
          <ul class="nav nav-pills panel whiteproper nav-justified">
            <li ><a href="<?php echo e(url('chakri')); ?>">All</a></li>
            <li class="active"><a href="<?php echo e(url('internships')); ?>">Internships</a></li>
            <li ><a href="<?php echo e(url('fulltime')); ?>">Full-Time</a></li>
            <li ><a href="<?php echo e(url('parttime')); ?>">Part-Time</a></li>
            <li ><a href="<?php echo e(url('onetime')); ?>">One-Time</a></li>
              <li><?php echo $__env->make('search.search',['url'=>'search'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></li>
          </ul>
        </div>
        <?php if(count($jobs)>0): ?>
          <?php foreach($jobs as $job): ?>
            <div class="col-md-3 col-md-offset-1 panel whiteproper">

              <h5 ><?php echo e($job->job_name); ?></h5>

                Type: <?php echo e($job->job_type); ?>

                <br>Location: <?php echo e($job->job_location); ?>

                <br>Salary: <?php echo e($job->job_salary); ?><br>

              <strong>Posted By <?php echo e($job->company_name); ?></strong><br>
              <strong>Posted on <?php echo e($job->created_at); ?></strong>

              <!-- Check if its recruter or not-->


              <form class="form-control" action="<?php echo e(url('show/jobs',$job->id)); ?>" method="GET">
                <?php echo csrf_field(); ?>



                <button type="submit" name="button" class="btn btn-default btn-lg">view</button>

              </form>


            </div>
              <br>

          <?php endforeach; ?>
        <?php endif; ?>


      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>