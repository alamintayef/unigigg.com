<div class="padsmall col-md-12" >
  <h4>Extra Curricular Activities</h4>



  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>
          Title
        </th>

        <th>
          Starting Date
        </th>
        <th>
          End Date
        </th>
        <th>
          Description
        </th>
        <th>Delete</th>

        <tr>
        </thead>
        <?php foreach($extracs as $excc): ?>
        <tbody>

            <tr>
              <td>
                <?php echo e($excc->excc_name); ?>

              </td>

              <td>
                <?php echo e($excc->excc_start_date); ?>

              </td>
              <td>
                <?php echo e($excc->excc_end_date); ?>

              </td>
              <td>
                <?php echo e($excc->excc_description); ?>

              </td>
              <td>
                <form action="<?php echo e(url('excc',$excc->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger ">
                    <i class="fa fa-trash"></i> 
                  </button>
                </form>
              </td>
            <?php endforeach; ?>

          </tbody>
        </table>
      </div>
