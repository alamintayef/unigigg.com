<?php $__env->startSection('content'); ?>
  <div class="container padtop">
    <div class="row">

      <div class="col-md-10 " style="font-size:12px;">
      
        <br>
        <?php if(count($jobs)>0): ?>


        <?php if(count($jobs)>0): ?>
          <?php foreach($jobs as $job): ?>
            <div class="col-md-3 col-md-offset-1 panel whiteproper">

              <h5 ><?php echo e($job->job_name); ?></h5>

                Type: <?php echo e($job->job_type); ?>

                <br>Location: <?php echo e($job->job_location); ?>

                <br>Salary: <?php echo e($job->job_salary); ?><br>

              <strong>Posted By <?php echo e($job->company_name); ?></strong><br>
              <strong>Posted on <?php echo e($job->created_at); ?></strong>

              <!-- Check if its recruter or not-->


                  <form class="form-control" action="<?php echo e(url('show/jobs',$job->job_id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>




                        <button type="submit" name="button" class="btn btn-default btn-lg">view</button>


                  </form>


            </div>
              <br>

          <?php endforeach; ?>
        <?php endif; ?>
      <?php else: ?>
        <h4>Sorry Nothing Found ...  :'( </h4>
      <?php endif; ?>

      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>