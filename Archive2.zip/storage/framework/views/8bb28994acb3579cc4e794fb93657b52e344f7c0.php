<?php $__env->startSection('content'); ?>
  <div class="container padtop" id="jobs">
    <div class="row">

      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="col-md-10 " style="font-size:12px; padding:5px">
        <?php if(count($jobs)>0): ?>
          <?php foreach($jobs as $job): ?>
            <!--
            <div class="col-md-3 col-md-offset-1 panel" style="background-color:white;">

              <h5 ><?php echo e($job->job_name); ?></h5>

                Type: <?php echo e($job->job_type); ?>

                <br>Location: <?php echo e($job->job_location); ?>

                <br>Salary: <?php echo e($job->job_salary); ?><br>

              <strong>Posted By <?php echo e($job->company_name); ?></strong><br>
              <strong>Posted on <?php echo e($job->created_at); ?></strong>

              <!-- Check if its recruter or not--


                  <form class="form-control" action="<?php echo e(url('show/ejobs',$job->id)); ?>" method="GET">
                    <?php echo csrf_field(); ?>


                    <button type="submit" name="button" class="btn btn-default btn-raised btn-xs pull-right">view</button>

                  </form>


            </div>
            --->
            <div class="table table-responsive">
              <tr>
                <td>
                  <strong> <?php echo e($job->job_name); ?></strong><br>Location: <?php echo e($job->job_location); ?>

                  <br>Salary: <?php echo e($job->job_salary); ?><br>
                  <strong>Posted By <?php echo e($job->company_name); ?></strong><br>
                </td>
              </tr>
            </div>
            <br>
          <?php endforeach; ?>
        <?php endif; ?>


      </div>

    </div>
  </div>
  <script type="text/javascript">
  (function ($) {
  $('#jobs').smoothState();
})(jQuery);
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>