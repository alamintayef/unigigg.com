<?php $__env->startSection('content'); ?>

  <div class="container padtop" id="excc">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-7">

        <ul class="nav nav-pills panel whiteproper">
          <li ><a href="<?php echo e(url('userinfo')); ?>">Basic Information</a></li>
          <li ><a href="<?php echo e(url('image')); ?>">Profile Pic</a></li>
          <li ><a href="<?php echo e(url('edu')); ?>">Education</a></li>
          <li ><a href="<?php echo e(url('skill')); ?>">Skills</a></li>
          <li ><a href="<?php echo e(url('experience')); ?>">Experience</a></li>
          <li ><a href="<?php echo e(url('refs')); ?>">Reference</a></li>
          <li class="active"><a href="<?php echo e(url('excc')); ?>">Extra-Curricular</a></li>
          <li ><a href="<?php echo e(url('interest')); ?>">Upload CV</a></li>
          <li ><a href="<?php echo e(url('hobby')); ?>">Cover Letter</a></li>
          <li><a href="<?php echo e(url('fun')); ?>">About You</a></li>
          <li><a href="<?php echo e(url('vdoprofile')); ?>">Video Profile</a></li>

        </ul>


          <div class="well">

            <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                <?php foreach($errors->all() as $error): ?>
                  <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>



            <?php echo $__env->make('student.forms.excc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      </div>
    </div>
    <div class="col-md-2 panel whiteproper">
      <h5 class="textb">Experiences you added</h5>
        <ul class="list-group">

      <?php foreach($var as $excc): ?>
        <li  class="list-group-item" id="excclist"><?php echo e($excc->excc_name); ?></li>
      <?php endforeach; ?>
      </ul>

    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>