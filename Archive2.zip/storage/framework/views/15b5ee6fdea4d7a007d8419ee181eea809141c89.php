<h1>Hello <?php echo e($calls->fname); ?> <?php echo e($calls->fname); ?> </h1>
<p>
    you been called on an interview for the postion: <?php echo e($calls->job_name); ?> by <?php echo e($calls->company_name); ?>.<br>
    You may please call and confirm the appointment <?php echo e($calls->company_phone); ?><br>

    We wish you best of luck <br>
    Regards,<br>
    <em>unigigg team</em>

</p>
