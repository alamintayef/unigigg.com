<?php $__env->startSection('content'); ?>


<div class="container padtop">
		<div class="row">
      <div class="col-md-8 panel whiteproper pad">
        <h2>Add Training</h2>
      <?php echo Form::open(array('url' => '/add/training/create')); ?>



      <div class="form-group">
        <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('training_type', 'Type:', ['class' => 'control-label']); ?>

        <?php echo Form::text('training_type', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('training_description', 'Description:', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('training_description', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('application_fee', 'Application Fee:', ['class' => 'control-label']); ?>

        <?php echo Form::text('application_fee', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('training_start_date', 'Event Date:', ['class' => 'control-label']); ?>

        <?php echo Form::date('training_start_date', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('application_dead_line', 'Deadline:', ['class' => 'control-label']); ?>

        <?php echo Form::date('application_dead_line', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('payment_method', 'Payment Method', ['class' => 'control-label']); ?>

        <?php echo Form::text('payment_method', null, ['class' => 'form-control']); ?>

      </div>
      <div class="form-group">
        <?php echo Form::label('organized_by', 'Organizer', ['class' => 'control-label']); ?>

        <?php echo Form::text('organized_by', null, ['class' => 'form-control']); ?>

      </div>


      <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


      <?php echo Form::close(); ?>



    </div>
    <div class="col-md-3 col-md-offset-1 panel padsmall">

      <h3>Added So Far</h3>
      <?php if(count($training)>0): ?>
        <?php foreach($training as $trainings): ?>
          <?php echo e($trainings->title); ?>


        <?php endforeach; ?>

      <?php endif; ?>

    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>