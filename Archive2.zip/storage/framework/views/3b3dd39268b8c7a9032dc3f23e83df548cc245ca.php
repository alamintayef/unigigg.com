
<div class="container padtop">
  <div class="row">



    <h3>Welcome <strong class="primary"><?php echo e(Auth::user()->name); ?>

    </strong> Sub Admin</h3>
    <?php if(count($errors)>0): ?>
      <div class="alert alert-danger">
        <?php foreach($errors->all() as $error): ?>
          <p><?php echo e($error); ?></p>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="col-md-4 card card-raised padsmall">
      <i class="fa fa-user fa-5x"></i>
      <h3><a href="admin">User board</a>
      <h4><?php echo e($allusers); ?></h4></h3>

    </div>
    <div class="col-md-4 panel padsmall">
      <i class="fa fa-users fa-5x"></i>
      <h3>
      <a href="<?php echo e(url('employerlist')); ?>">
      Employer board</a>
      <h4><?php echo e($allemployer); ?></h4>
      </h3>
    </div>
    <div class="col-md-4 panel padsmall">
      <i class="fa fa-dashboard fa-5x"></i>
      <h3>
      <a href="<?php echo e(url('admin/job/board')); ?>">Job board</a>
      <h4><?php echo e($jobcount); ?></h4>
      </h3>
    </div>
    <div class="col-md-4 panel padsmall">
      <i class="fa fa-check fa-5x"></i>
      <h3>
      <a href="<?php echo e(url('verification')); ?>">Verification Request</a>

      </h3>
    </div>
    <div class="col-md-4 panel padsmall">
      <i class="fa fa-plus fa-5x"></i>
      <h3>
      <a href="<?php echo e(url('Area')); ?>">Add Area</a>

      </h3>
    </div>
<!--
  <div class="col-sm-4 panel col-sm-offset-1">

      <ul class="list-group">
        <!--
       <li class="list-group-item"><a href="<?php echo e(url('verification')); ?>">Show Verification Request</a</li>


       <li class="list-group-item"><a href="<?php echo e(url('area')); ?>">Add area</a></li>
       <li class="list-group-item"><a href="<?php echo e(url('managejobs')); ?>">Cron Jobs</a></li>
       <li class="list-group-item"><a href="<?php echo e(url('manage/odd/jobs')); ?>">Eccentric Cron Jobs</a></li>
       <li class="list-group-item"><a href="<?php echo e(url('call/for/in')); ?>">Call For interview Request</a></li>
       <li class="list-group-item"><a href="admin">User board</a> <span class="badge"> <?php echo e($allusers); ?></span></li>
       <li class="list-group-item"><a href="<?php echo e(url('admin/job/board')); ?>">Job board</a></li>
       <li class="list-group-item">Total Eccentric Jobs : <?php echo e(count($allOddJobs)); ?></li>
       <li class="list-group-item">Total Jobs : <?php echo e(count($allJobs)); ?></li>
      <li class="list-group-item"><a href="<?php echo e(url('addvdo')); ?>">Add video</a</li>
      <li class="list-group-item"><a href="<?php echo e(url('add/competition')); ?>">Add Competition</a</li>
      <li class="list-group-item"><a href="<?php echo e(url('add/training')); ?>">Add Training</a</li>
       <li class="list-group-item"><a href="<?php echo e(url('employerlist')); ?>">Employer board</a><span class="badge"> <?php echo e($allemployer); ?> </span></li>

       <li class="list-group-item">
         <?php echo Form::open(['method'=>'GET','url'=>'search','class'=>'form-inline']); ?>

           <input type="text" class="form-control" name="search" placeholder="Search...">
           <button class="btn btn-default-sm" type="submit">
             <i class="fa fa-search"></i>
             </button>
         <?php echo Form::close(); ?>

       </li>
       <li class="list-group-item"><a href="<?php echo e(url('adduniversity')); ?>">Add University</a> <span class="badge"><?php echo e($uni); ?></span></li>
      </ul>


  </div>
  <div class="col-md-4 card-raised col-md-offset-1 whiteproper">
    <a href="<?php echo e(url('admin/create/user')); ?>" class="btn btn-link"><i class="fa fa-plus"></i> Create <i class="fa fa-user"></i></a>

  </div>
-->

    <?php if(notify()->ready()): ?>
      <script>
      swal({
        title: "<?php echo notify()->message(); ?>",
        text: "<?php echo notify()->option('text'); ?>",
        type: "<?php echo e(notify()->type()); ?>",
        <?php if(notify()->option('timer')): ?>
        timer: <?php echo e(notify()->option('timer')); ?>,
        showConfirmButton: false
        <?php endif; ?>
      });
      </script>
    <?php endif; ?>








</div>
</div>
</div>
