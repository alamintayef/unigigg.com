<hr>
<div class="padsmall">

  <h5>Your CV Link</h5>

    <div class="col-md-12 col-md-8-offset-1 well-sm ">
      <?php if(count($interest)>0): ?>
        <strong>CV:</strong><a href="<?php echo e($interest->interest_name); ?>"><?php echo e($interest->interest_name); ?></a>
        <form action="<?php echo e(url('interest',$interest->interest_id)); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <button type="submit" class="btn btn-danger pull-right">
            <i class="fa fa-edit"></i>
          </button>
        </form>
          <?php endif; ?>
    </div>

</div>
<hr>
