<title>Employer Board</title>
<?php $__env->startSection('content'); ?>

      <div class="padtop">
        <h2>Employer Board</h2>
        <div class="panel">


      <div class="table-responsive">

      <table class="table table-bordered">
        <thead>
          <th>
            Name
          </th>
          <th>
            email
          </th>
          <th>
            View Profile
          </th>
          <th>
            Verify
          </th>
          <th>
            Status
          </th>
          <th>Sub Type </th>
          <th>
            Delete
          </th>
        </thead>
        <tbody>
          <?php foreach($allemployer as $users): ?>
            <tr>
              <td>
                <?php echo e($users->name); ?>

              </td>
              <td>
                <?php echo e($users->email); ?>

              </td>
              <td>
                <form  action="<?php echo e(url('/employer/profile',$users->id)); ?>" method="GET">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-primary">
                    <i class="fa fa-user"></i>
                  </button>
                </form>
              </td>
              <td>
                <form  action="<?php echo e(url('verify/employer',$users->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-success">
                    <i class="fa fa-check-circle"></i>
                  </button>
                </form>
              </td>
              <?php if($users->verified===0): ?>
                <td>
                  <p class="text-danger">
                    Not verified
                  </p>
                </td>
              <?php else: ?>
                <td>
                  <p class="text-success">
                   verified
                  </p>
                </td>
              <?php endif; ?>
              <td>
                <form  action="<?php echo e(url('update/employer/subscripton',$users->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-info">
                    Change
                  </button>
                </form>
              </td>
              <td>
                <form  action="<?php echo e(url('admin/delete/user',$users->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger">
                    <i class="fa fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
            <?php echo e($allemployer->links()); ?>

        </tbody>
      </table>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>