<?php $__env->startSection('content'); ?>
  <div class="container padtop" id="dash">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10">
        <div class="panel panel-default">
          <div class="panel-heading"><h3>Dashboard</h3>
            <!--
            <?php if(Auth::user()->verified===0): ?>
             <p class="">
               <button  class="btn btn-link btn-danger">Not Verified</button>

             </p>
            <?php else: ?>
              <p class="">
                <button  class="btn btn-link btn-success">Verified</button>

              </p>
            <?php endif; ?>
          -->
          </div>

          <div class="panel-body">
            <div>
              <?php if(notify()->ready()): ?>
                <script>
                swal({
                  title: "<?php echo notify()->message(); ?>",
                  text: "<?php echo notify()->option('text'); ?>",
                  type: "<?php echo e(notify()->type()); ?>",
                  <?php if(notify()->option('timer')): ?>
                  timer: <?php echo e(notify()->option('timer')); ?>,
                  showConfirmButton: false
                  <?php endif; ?>
                });
                </script>
              <?php endif; ?>



            <h2>Welcome <strong class="primary"><?php echo e(Auth::user()->name); ?>

            ,</strong></h2>

            <?php if(count($eminfos)==0): ?>
              <p>
                The first thing you would like to do is build up your profile <a href="<?php echo e(url('employerinfo')); ?>">Here</a>
              </p>
            <?php endif; ?>

            </div>
            <div class="">
            <?php if(count($images)>0): ?>

                <img src="<?php echo 'files/images/'.$images->filePath; ?>" alt="propic" height="100px" width="100px" style="border-radius:20%;" />

            <?php endif; ?>
          </div>

            <hr>
            <div >
              <?php if(count($eminfos)>0): ?>
                <div class="pad">

                  <a href="<?php echo e(url('employerinfo')); ?>" class="btn btn-default btn-sm pull-right"><i class="fa fa-edit"></i> Edit</a>


                    <div class="">


                    <div class="pull-left">
                      <h4>Company Information:</h4>
                      <p>Company Name: <?php echo e($eminfos->company_name); ?>  </p>
                      <p>  Company Type: <?php echo e($eminfos->company_type); ?>  </p>
                      <p>  Company Size: <?php echo e($eminfos->company_size); ?>  </p>
                      <p>
                        <h5>You have posted <em> <?php echo e($jobcount); ?> </em>jobs</h5>
                      </p>
                    </div>
                    <div class="pull-right">
                      <p><h4>Company Description:</h4> <?php echo e($eminfos->company_description); ?></p>
                      <p>Company Email: <?php echo e($eminfos->company_email); ?></p>
                      <p>Company Contact: <?php echo e($eminfos->company_phone); ?></p>
                        </div>

                  </div>




                </div>

              <?php endif; ?>




            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript">
  (function ($) {
    $('#dash').smoothState();
})(jQuery);

  </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>