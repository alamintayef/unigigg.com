<ul class="nav nav-pills whiteproper">
  <li class="active"><a href="#">Home</a></li>
  <li><a href="edu">Degree</a></li>
  <li><a href="#">Skills</a></li>
  <li><a href="#">Experience</a></li>
  <li><a href="#">Reference</a></li>
  <li><a href="#">Extra-Curricular</a></li>

</ul>
