<?php

/*
|--------------------------------------------------------------------------
|Smsgateway Credentials
|--------------------------------------------------------------------------
|
| Insert your credentials to use smsgateway API
|
*/

return [
    'email' => 'tayef56@yahoo.com',
    'password' => 'r58num1sarker'
];
