<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>

  </head>
  <body>
    <p>
      Dear <h4>{{$user->name}}</h4>,
      We hope you are doing good. Your profile is seems incomplete,please fill up your profile as it will be used as your public resume.If you need any help please do inform us @ www.facebook.com/tayeif. We will be happy to help.<br>

      Best,
      tayef,
      CEO/Co-Founder, <em>unigigg</em>

    </p>

  </body>
</html>
