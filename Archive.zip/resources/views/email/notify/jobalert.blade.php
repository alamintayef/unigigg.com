<!DOCTYPE html>
<html lang="en">

  <body>
    Dear <h4>{{$user->name}}</h4>
    <p>

      A new job has been posted! <br>
      Please check the jobboard from your dashboard to see the job details. <br>

      Please verify your profile to apply to the jobs if not yet verified <br>

      Thank you


      Best,<br>
      Tayef,<br>
      CEO/Co-Founder, <em>unigigg</em>

    </p>

  </body>
</html>
