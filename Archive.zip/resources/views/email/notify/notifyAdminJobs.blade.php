<!DOCTYPE html>
<html lang="en">

  <body>


     <h4>{{( $info['fname'])}} {{ ($info['lname'] )}}</h4>
    <p>

      Has applied to <strong> {{($info['job_name'] )}}</strong>

    </p>

  </body>
</html>
