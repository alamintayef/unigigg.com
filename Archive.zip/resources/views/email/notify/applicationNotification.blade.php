<!DOCTYPE html>
<html lang="en">

  <body>
    Dear <h4>{{$user->fname}} {{$user->lname}}</h4>
    <p>

      Thank you for applying. We have recieved your application. <br>
      We will make sure that your application reaches the <em>Employer</em>.<br>
      We will get back to you soon.

      Thank you for using unigigg <br>

      Best,<br>
      tayef,<br>
      CEO/Co-Founder, <em>unigigg</em>

    </p>

  </body>
</html>
