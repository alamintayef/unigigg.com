<footer class="footer" id="dark-section" style="padding:26px">
  <div class="container">
    <div class="col-md-4">
      <h3><i class="fa fa-graduation-cap text-primary"></i><span class="textw">unigigg</span></h3>
      <h5 class="textw">
      <br>
      We are on a mission to make the hiring process transparent and automated in Bangladesh.
    </h5>

    </div>
    <div class="col-md-4">

      <h5><a href="{{url('about')}}">About Us</a></h5>
      <h5><a href="{{url('coming/soon')}}">Team</a></h5>
      <h5><a href="faqs">FAQs</a><br></h5>
      <h5><a href="{{url('terms&services')}}">Terms and Conditions</a></h5>
      <h5><a href="{{url('vlog')}}">Vlog</a></h5>
      <h5><a href="{{url('blogs')}}">Blog</a></h5>
      <h5><a href="{{url('recruiter')}}">Recruiter</a></h5>
      <h5><a href="{{url('talent')}}">Talent</a></h5>

    </div>
    <div class="col-md-4">
      <h4 class="text-primary">Contact</h4>
      <p class="textw">
        <strong>Email <i class="fa fa-envelope"></i> :</strong><br>
        info@unigigg.com <br>
        <strong>Call Us <i class="fa fa-phone fa-1x"></i></strong>:<br> +880-1987847548   <strong class="pull-right"><a href="https://www.facebook.com/unigigg"  target="_blank"><i class="fa fa-facebook-square fa-4x"></i></a></strong>
        <br><strong>Meet Us <i class="fa fa-map-marker fa-1x"></i></strong>:<br> House-12,Road-5,<br> Block-C,Section-2 <br>
        Mirpur,Dhaka-1216 <br>

      </p>
      <!-- Start of StatCounter Code for Default Guide -->


    </div>


  </div>
</footer>
