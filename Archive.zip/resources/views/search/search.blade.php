

  {!! Form::open(['method'=>'GET','url'=>$url,'class'=>'navbar-form'])  !!}
    <input type="text" class="form-control" name="search" placeholder="type and press enter">

  {!! Form::close() !!}
