<footer class="footer" id="dark-section" style="padding:26px">
  <div class="container">
    <div class="col-md-4">
      <h3><i class="fa fa-graduation-cap text-primary"></i><span class="textw">unigigg</span></h3>
      <h5 class="textw">
      <br>
      We are on a mission to help our youth build better future and help employers attract proactive talents.
    </h5>

    </div>
    <div class="col-md-4">
      <br>
      <h5><a href="{{url('about')}}">About Us</a></h5>
      <h5><a href="faqs">Faqs </a><br></h5>
      <h5><a href="{{url('terms&services')}}">Terms and Conditions</a></h5>
      <h5><a href="{{url('vlog')}}">Vlog</a></h5>
        <h5><a href="{{url('blog')}}">Blog</a></h5>
      <h5><a href="{{url('recruiter')}}">Recruiter</a></h5>
      <h5><a href="{{url('talent')}}">Talent</a></h5>

    </div>
    <div class="col-md-4">
      <h4 class="text-primary">Contact</h4>
      <p class="textw">
        <strong>Email <i class="fa fa-envelope"></i> :</strong><br>
        info@unigigg.com <br>
        <strong>Call Us <i class="fa fa-phone fa-1x"></i></strong>:<br> +880-1987847548   <strong class="pull-right"><a href="https://www.facebook.com/unigigg"  target="_blank"><i class="fa fa-facebook-square fa-4x"></i></a></strong>
        <br><strong>Meet Us <i class="fa fa-map-marker fa-1x"></i></strong>:<br> House-12,Road-5,<br> Block-C,Section-2 <br>
        Mirpur,Dhaka-1216 <br>

      </p>
      <!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=10985134; 
var sc_invisible=0; 
var sc_security="af7ba994"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="web statistics"
href="http://statcounter.com/" target="_blank"><img
class="statcounter"
src="//c.statcounter.com/10985134/0/af7ba994/0/" alt="web
statistics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->

    </div>


  </div>
</footer>